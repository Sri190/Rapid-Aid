import React from 'react';
import { Settings as SettingsIcon, Bell, Shield, Palette, Database, Sliders } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const Settings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <SettingsIcon className="w-7 h-7 text-primary" />
          Settings
        </h1>
        <p className="text-muted-foreground mt-1">Configure system preferences and options</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-500" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="sound">Sound Alerts</Label>
              <Switch id="sound" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="desktop">Desktop Notifications</Label>
              <Switch id="desktop" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="email">Email Alerts</Label>
              <Switch id="email" />
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-500" />
              Security
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="2fa">Two-Factor Auth</Label>
              <Switch id="2fa" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="session">Session Timeout (30 min)</Label>
              <Switch id="session" defaultChecked />
            </div>
            <Button variant="outline" className="w-full">Change Password</Button>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Sliders className="w-5 h-5 text-purple-500" />
              AI Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="ai-suggest">AI Suggestions</Label>
              <Switch id="ai-suggest" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="auto-backup">Auto Backup Switch</Label>
              <Switch id="auto-backup" />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="priority-recalc">Real-time Priority Recalc</Label>
              <Switch id="priority-recalc" defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Database className="w-5 h-5 text-orange-500" />
              Data & Storage
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Storage Used</span>
              <span className="text-sm font-medium">2.4 GB / 10 GB</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-primary h-2 rounded-full" style={{ width: '24%' }} />
            </div>
            <Button variant="outline" className="w-full">Clear Cache</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Settings;
