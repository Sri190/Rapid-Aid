import React from 'react';
import { History, MapPin, Clock, User, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const mockHistory = [
  { id: 'EM-005', type: 'Slip and Fall', location: 'Shopping Mall', time: '45 min ago', status: 'resolved', priority: 'low' },
  { id: 'EM-006', type: 'Chest Pain', location: '789 Residential Ave', time: '2 hours ago', status: 'resolved', priority: 'high' },
  { id: 'EM-007', type: 'Minor Accident', location: 'Parking Lot B', time: '3 hours ago', status: 'resolved', priority: 'medium' },
  { id: 'EM-008', type: 'Allergic Reaction', location: 'School Cafeteria', time: '4 hours ago', status: 'resolved', priority: 'medium' },
  { id: 'EM-009', type: 'Breathing Difficulty', location: 'Office Building', time: '5 hours ago', status: 'resolved', priority: 'high' },
];

const IncidentHistory: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <History className="w-7 h-7 text-primary" />
            Incident History
          </h1>
          <p className="text-muted-foreground mt-1">View past emergency incidents and outcomes</p>
        </div>
        <Button variant="outline">Export Report</Button>
      </div>

      <div className="space-y-4">
        {mockHistory.map((incident) => (
          <Card key={incident.id} className="medical-card cursor-pointer hover:shadow-lg transition-all">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className={cn(
                  'w-3 h-3 rounded-full',
                  incident.priority === 'high' && 'bg-red-500',
                  incident.priority === 'medium' && 'bg-yellow-500',
                  incident.priority === 'low' && 'bg-green-500'
                )} />
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <h3 className="font-semibold">{incident.type}</h3>
                    <span className="text-xs font-mono text-muted-foreground">{incident.id}</span>
                    <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600">
                      {incident.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {incident.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {incident.time}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default IncidentHistory;
