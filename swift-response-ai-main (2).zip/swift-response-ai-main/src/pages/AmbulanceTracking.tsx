import React from 'react';
import { useEmergency } from '@/contexts/EmergencyContext';
import { useNavigate } from 'react-router-dom';
import {
  Ambulance,
  MapPin,
  Clock,
  User,
  Phone,
  Navigation,
  Battery,
  Signal,
  ChevronRight,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const AmbulanceTracking: React.FC = () => {
  const { ambulances, emergencies } = useEmergency();
  const navigate = useNavigate();

  const getEmergencyForAmbulance = (emergencyId?: string) => {
    return emergencies.find(e => e.id === emergencyId);
  };

  const statusColors = {
    available: 'bg-green-100 text-green-700 border-green-200',
    dispatched: 'bg-blue-100 text-blue-700 border-blue-200',
    'en-route': 'bg-purple-100 text-purple-700 border-purple-200',
    'on-scene': 'bg-orange-100 text-orange-700 border-orange-200',
    returning: 'bg-gray-100 text-gray-700 border-gray-200',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Ambulance Tracking</h1>
          <p className="text-muted-foreground mt-1">Real-time fleet monitoring and dispatch status</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span>Available: {ambulances.filter(a => a.status === 'available').length}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-blue-500" />
            <span>Active: {ambulances.filter(a => a.status !== 'available').length}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {ambulances.map((ambulance) => {
          const emergency = getEmergencyForAmbulance(ambulance.currentEmergency);
          
          return (
            <Card 
              key={ambulance.id} 
              className={cn(
                'medical-card transition-all duration-200 hover:shadow-lg cursor-pointer',
                ambulance.status !== 'available' && 'ring-2 ring-blue-200'
              )}
              onClick={() => navigate('/map')}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center',
                      ambulance.status === 'available' ? 'bg-green-100' : 'bg-blue-100'
                    )}>
                      <Ambulance className={cn(
                        'w-6 h-6',
                        ambulance.status === 'available' ? 'text-green-600' : 'text-blue-600'
                      )} />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{ambulance.callSign}</CardTitle>
                      <p className="text-xs text-muted-foreground font-mono">{ambulance.id}</p>
                    </div>
                  </div>
                  <span className={cn(
                    'px-3 py-1 rounded-full text-xs font-semibold border',
                    statusColors[ambulance.status]
                  )}>
                    {ambulance.status}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Crew */}
                <div className="flex items-center gap-2 text-sm">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span>{ambulance.crew.join(', ')}</span>
                </div>

                {/* Location */}
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span>
                    {ambulance.location.lat.toFixed(4)}, {ambulance.location.lng.toFixed(4)}
                  </span>
                </div>

                {/* Current Emergency */}
                {emergency && (
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-blue-700 uppercase">Current Assignment</span>
                      {ambulance.eta && (
                        <span className="text-sm font-bold text-blue-700">ETA: {ambulance.eta} min</span>
                      )}
                    </div>
                    <p className="font-medium text-sm">{emergency.type}</p>
                    <p className="text-xs text-muted-foreground truncate">{emergency.location.address}</p>
                  </div>
                )}

                {/* Status Indicators */}
                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Battery className="w-4 h-4 text-green-500" />
                      <span className="text-xs">98%</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Signal className="w-4 h-4 text-green-500" />
                      <span className="text-xs">Strong</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    Details <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="text-lg">Fleet Actions</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <Button onClick={() => navigate('/map')}>
            <Navigation className="w-4 h-4 mr-2" />
            View All on Map
          </Button>
          <Button variant="outline" onClick={() => navigate('/route-planning')}>
            Optimize Routes
          </Button>
          <Button variant="outline" onClick={() => navigate('/resources')}>
            Resource Status
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default AmbulanceTracking;
