import React from 'react';
import { useEmergency } from '@/contexts/EmergencyContext';
import { useNavigate } from 'react-router-dom';
import {
  Building2,
  Bed,
  Activity,
  Users,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  ChevronRight,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

const HospitalCapacity: React.FC = () => {
  const { hospitals } = useEmergency();
  const navigate = useNavigate();

  const statusConfig = {
    accepting: { color: 'bg-green-100 text-green-700 border-green-200', label: 'Accepting' },
    limited: { color: 'bg-yellow-100 text-yellow-700 border-yellow-200', label: 'Limited' },
    diverting: { color: 'bg-red-100 text-red-700 border-red-200', label: 'Diverting' },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Hospital Capacity</h1>
          <p className="text-muted-foreground mt-1">Real-time bed availability and ER status</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span>Accepting: {hospitals.filter(h => h.status === 'accepting').length}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <span>Limited: {hospitals.filter(h => h.status === 'limited').length}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <span>Diverting: {hospitals.filter(h => h.status === 'diverting').length}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {hospitals.map((hospital) => {
          const erPercentage = (hospital.erCurrent / hospital.erCapacity) * 100;
          const bedPercentage = ((hospital.totalBeds - hospital.availableBeds) / hospital.totalBeds) * 100;
          const icuPercentage = ((hospital.icuBeds - hospital.icuAvailable) / hospital.icuBeds) * 100;

          return (
            <Card key={hospital.id} className="medical-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center',
                      hospital.status === 'accepting' && 'bg-green-100',
                      hospital.status === 'limited' && 'bg-yellow-100',
                      hospital.status === 'diverting' && 'bg-red-100'
                    )}>
                      <Building2 className={cn(
                        'w-6 h-6',
                        hospital.status === 'accepting' && 'text-green-600',
                        hospital.status === 'limited' && 'text-yellow-600',
                        hospital.status === 'diverting' && 'text-red-600'
                      )} />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{hospital.name}</CardTitle>
                      <p className="text-xs text-muted-foreground font-mono">{hospital.id}</p>
                    </div>
                  </div>
                  <span className={cn(
                    'px-3 py-1 rounded-full text-xs font-semibold border',
                    statusConfig[hospital.status].color
                  )}>
                    {statusConfig[hospital.status].label}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* ER Capacity */}
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium flex items-center gap-2">
                      <Activity className="w-4 h-4 text-red-500" />
                      Emergency Room
                    </span>
                    <span className={cn(
                      'font-semibold',
                      erPercentage >= 90 ? 'text-red-600' : erPercentage >= 70 ? 'text-yellow-600' : 'text-green-600'
                    )}>
                      {hospital.erCurrent}/{hospital.erCapacity}
                    </span>
                  </div>
                  <Progress 
                    value={erPercentage} 
                    className={cn(
                      'h-3',
                      erPercentage >= 90 ? '[&>div]:bg-red-500' : erPercentage >= 70 ? '[&>div]:bg-yellow-500' : '[&>div]:bg-green-500'
                    )} 
                  />
                </div>

                {/* General Beds */}
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium flex items-center gap-2">
                      <Bed className="w-4 h-4 text-blue-500" />
                      General Beds
                    </span>
                    <span className="font-semibold">
                      {hospital.availableBeds} available / {hospital.totalBeds}
                    </span>
                  </div>
                  <Progress value={bedPercentage} className="h-3 [&>div]:bg-blue-500" />
                </div>

                {/* ICU */}
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-purple-500" />
                      ICU Beds
                    </span>
                    <span className={cn(
                      'font-semibold',
                      hospital.icuAvailable === 0 ? 'text-red-600' : 'text-green-600'
                    )}>
                      {hospital.icuAvailable} available / {hospital.icuBeds}
                    </span>
                  </div>
                  <Progress 
                    value={icuPercentage} 
                    className={cn(
                      'h-3',
                      hospital.icuAvailable === 0 ? '[&>div]:bg-red-500' : '[&>div]:bg-purple-500'
                    )} 
                  />
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 gap-4 pt-3 border-t">
                  <div className="text-center p-2 bg-gray-50 rounded-lg">
                    <div className="text-xl font-bold text-foreground">{hospital.availableBeds}</div>
                    <div className="text-xs text-muted-foreground">Available Beds</div>
                  </div>
                  <div className="text-center p-2 bg-gray-50 rounded-lg">
                    <div className="text-xl font-bold text-foreground">{hospital.icuAvailable}</div>
                    <div className="text-xs text-muted-foreground">ICU Available</div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => navigate('/map')}
                  >
                    View on Map
                  </Button>
                  <Button 
                    size="sm" 
                    className="flex-1"
                    onClick={() => navigate(`/emergency-details`)}
                  >
                    Route Patient
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="medical-card">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-green-600">
              {hospitals.reduce((sum, h) => sum + h.availableBeds, 0)}
            </div>
            <div className="text-sm text-muted-foreground">Total Available Beds</div>
          </CardContent>
        </Card>
        <Card className="medical-card">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-purple-600">
              {hospitals.reduce((sum, h) => sum + h.icuAvailable, 0)}
            </div>
            <div className="text-sm text-muted-foreground">ICU Beds Available</div>
          </CardContent>
        </Card>
        <Card className="medical-card">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-blue-600">
              {hospitals.reduce((sum, h) => sum + h.erCapacity - h.erCurrent, 0)}
            </div>
            <div className="text-sm text-muted-foreground">ER Capacity Remaining</div>
          </CardContent>
        </Card>
        <Card className="medical-card">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-foreground">
              {hospitals.length}
            </div>
            <div className="text-sm text-muted-foreground">Hospitals in Network</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default HospitalCapacity;
