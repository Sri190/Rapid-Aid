import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useEmergency } from '@/contexts/EmergencyContext';
import {
  AlertTriangle,
  MapPin,
  Phone,
  User,
  Clock,
  Ambulance,
  Building2,
  Navigation,
  MessageSquare,
  CheckCircle,
  XCircle,
  RefreshCw,
  ChevronRight,
  Activity,
  Users,
  FileText,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

const EmergencyDetails: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { emergencies, ambulances, hospitals, dispatchAmbulance } = useEmergency();
  const [showDispatchDialog, setShowDispatchDialog] = useState(false);
  const [showBackupDialog, setShowBackupDialog] = useState(false);
  const [showHospitalDialog, setShowHospitalDialog] = useState(false);
  const [notes, setNotes] = useState('');

  const emergency = emergencies.find(e => e.id === id) || emergencies[0];
  const assignedAmbulance = ambulances.find(a => a.id === emergency?.assignedAmbulance);
  const availableAmbulances = ambulances.filter(a => a.status === 'available');
  const backupAmbulances = ambulances.filter(a => a.status === 'available' || a.status === 'returning');

  if (!emergency) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">Emergency not found</p>
      </div>
    );
  }

  const handleDispatch = (ambulanceId: string) => {
    dispatchAmbulance(emergency.id, ambulanceId);
    setShowDispatchDialog(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={cn(
            'w-14 h-14 rounded-xl flex items-center justify-center',
            emergency.priority === 'high' && 'bg-red-100',
            emergency.priority === 'medium' && 'bg-yellow-100',
            emergency.priority === 'low' && 'bg-green-100'
          )}>
            <AlertTriangle className={cn(
              'w-7 h-7',
              emergency.priority === 'high' && 'text-red-600',
              emergency.priority === 'medium' && 'text-yellow-600',
              emergency.priority === 'low' && 'text-green-600'
            )} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{emergency.type}</h1>
            <p className="text-muted-foreground flex items-center gap-2">
              <span className="font-mono">{emergency.id}</span>
              <span className={cn(
                'text-xs font-semibold px-2 py-1 rounded-full',
                emergency.status === 'incoming' && 'bg-yellow-100 text-yellow-700',
                emergency.status === 'dispatched' && 'bg-blue-100 text-blue-700',
                emergency.status === 'en-route' && 'bg-purple-100 text-purple-700',
                emergency.status === 'on-scene' && 'bg-green-100 text-green-700'
              )}>
                {emergency.status}
              </span>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={() => navigate('/map')}>
            <MapPin className="w-4 h-4 mr-2" />
            View on Map
          </Button>
          <Button variant="outline" onClick={() => navigate('/backup-failover')}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Backup Options
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Caller & Location */}
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">Caller Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-medium">{emergency.callerInfo.name}</p>
                    <p className="text-sm text-muted-foreground">{emergency.callerInfo.phone}</p>
                  </div>
                </div>
                <div className={cn(
                  'px-4 py-3 rounded-lg',
                  emergency.callerInfo.emotionState === 'calm' && 'bg-green-50 text-green-700',
                  emergency.callerInfo.emotionState === 'anxious' && 'bg-yellow-50 text-yellow-700',
                  emergency.callerInfo.emotionState === 'panic' && 'bg-red-50 text-red-700'
                )}>
                  <span className="text-xs uppercase font-semibold">Caller State</span>
                  <p className="font-medium capitalize">{emergency.callerInfo.emotionState}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-red-500 mt-1" />
                  <div>
                    <p className="font-medium">{emergency.location.address}</p>
                    <p className="text-sm text-muted-foreground">
                      {emergency.location.lat.toFixed(4)}, {emergency.location.lng.toFixed(4)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="font-medium">
                      {Math.floor((Date.now() - emergency.timeReceived.getTime()) / 60000)} minutes ago
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {emergency.timeReceived.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Resources */}
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">Assigned Resources</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-6">
              {/* Primary Ambulance */}
              <div className="p-4 border rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs uppercase font-semibold text-muted-foreground">Primary Ambulance</span>
                  <Ambulance className="w-5 h-5 text-blue-500" />
                </div>
                {assignedAmbulance ? (
                  <>
                    <p className="font-semibold text-lg">{assignedAmbulance.callSign}</p>
                    <p className="text-sm text-muted-foreground">{assignedAmbulance.crew.join(', ')}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <span className={cn(
                        'text-xs px-2 py-1 rounded-full',
                        assignedAmbulance.status === 'dispatched' && 'bg-blue-100 text-blue-700',
                        assignedAmbulance.status === 'en-route' && 'bg-purple-100 text-purple-700'
                      )}>
                        {assignedAmbulance.status}
                      </span>
                      {assignedAmbulance.eta && (
                        <span className="text-sm font-bold text-primary">ETA: {assignedAmbulance.eta} min</span>
                      )}
                    </div>
                  </>
                ) : (
                  <Button className="w-full mt-2" onClick={() => setShowDispatchDialog(true)}>
                    Dispatch Ambulance
                  </Button>
                )}
              </div>

              {/* Backup Ambulance */}
              <div className="p-4 border rounded-xl border-dashed">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs uppercase font-semibold text-muted-foreground">Backup Ambulance</span>
                  <RefreshCw className="w-5 h-5 text-orange-500" />
                </div>
                <p className="font-semibold text-lg">Rescue 4</p>
                <p className="text-sm text-muted-foreground">Standby - 2.3 km away</p>
                <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => setShowBackupDialog(true)}>
                  Switch to Backup
                </Button>
              </div>

              {/* Primary Hospital */}
              <div className="p-4 border rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs uppercase font-semibold text-muted-foreground">Primary Hospital</span>
                  <Building2 className="w-5 h-5 text-green-500" />
                </div>
                <p className="font-semibold text-lg">{emergency.assignedHospital || 'City General Hospital'}</p>
                <p className="text-sm text-muted-foreground">ER: 18/60 capacity</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700">Accepting</span>
                  <span className="text-sm font-bold text-green-600">ETA: 12 min</span>
                </div>
              </div>

              {/* Backup Hospital */}
              <div className="p-4 border rounded-xl border-dashed">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs uppercase font-semibold text-muted-foreground">Backup Hospital</span>
                  <Building2 className="w-5 h-5 text-orange-500" />
                </div>
                <p className="font-semibold text-lg">Metro Medical Center</p>
                <p className="text-sm text-muted-foreground">ER: 41/45 capacity</p>
                <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => setShowHospitalDialog(true)}>
                  Switch Hospital
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Notes & Transcript */}
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">Notes & Transcript</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {emergency.transcript && (
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                    <MessageSquare className="w-4 h-4" />
                    <span>Call Transcript</span>
                  </div>
                  <p className="text-sm italic">"{emergency.transcript}"</p>
                </div>
              )}
              
              <div>
                <label className="text-sm font-medium mb-2 block">Operator Notes</label>
                <div className="space-y-2">
                  {emergency.notes.map((note, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 bg-blue-50 rounded-lg">
                      <FileText className="w-4 h-4 text-blue-500 mt-0.5" />
                      <span className="text-sm">{note}</span>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2 mt-3">
                  <Textarea
                    placeholder="Add a note..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="h-20"
                  />
                  <Button className="self-end">Add Note</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Priority Card */}
          <Card className="medical-card">
            <CardContent className="p-6">
              <div className="text-center">
                <div className={cn(
                  'inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4',
                  emergency.priority === 'high' && 'bg-red-100 text-red-700',
                  emergency.priority === 'medium' && 'bg-yellow-100 text-yellow-700',
                  emergency.priority === 'low' && 'bg-green-100 text-green-700'
                )}>
                  <AlertTriangle className="w-4 h-4" />
                  <span className="font-semibold uppercase">{emergency.priority} Priority</span>
                </div>
                <div className="text-5xl font-bold text-foreground">{emergency.priorityScore}</div>
                <p className="text-sm text-muted-foreground mt-1">AI Priority Score</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-4"
                  onClick={() => navigate('/priority-queue')}
                >
                  View AI Breakdown
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="medical-card">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Severity</span>
                <span className="font-semibold">{emergency.severity}/10</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">People Affected</span>
                <span className="font-semibold">{emergency.peopleAffected}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Category</span>
                <span className="font-semibold capitalize">{emergency.category}</span>
              </div>
              {emergency.eta && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Current ETA</span>
                  <span className="font-semibold text-primary">{emergency.eta} min</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <Card className="medical-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button className="w-full" onClick={() => setShowDispatchDialog(true)}>
                <CheckCircle className="w-4 h-4 mr-2" />
                Confirm Dispatch
              </Button>
              <Button variant="outline" className="w-full" onClick={() => setShowBackupDialog(true)}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Simulate Delay
              </Button>
              <Button variant="outline" className="w-full" onClick={() => setShowHospitalDialog(true)}>
                <Building2 className="w-4 h-4 mr-2" />
                Simulate Hospital Full
              </Button>
              <Button variant="outline" className="w-full" onClick={() => navigate('/backup-failover')}>
                <Activity className="w-4 h-4 mr-2" />
                View Backup Options
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Dispatch Dialog */}
      <Dialog open={showDispatchDialog} onOpenChange={setShowDispatchDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Dispatch Ambulance</DialogTitle>
            <DialogDescription>
              Select an available ambulance to dispatch to this emergency.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            {availableAmbulances.length > 0 ? (
              availableAmbulances.map((amb) => (
                <div
                  key={amb.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                  onClick={() => handleDispatch(amb.id)}
                >
                  <div className="flex items-center gap-3">
                    <Ambulance className="w-6 h-6 text-blue-500" />
                    <div>
                      <p className="font-medium">{amb.callSign}</p>
                      <p className="text-sm text-muted-foreground">{amb.crew.join(', ')}</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-4">No ambulances currently available</p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDispatchDialog(false)}>Cancel</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Backup Dialog */}
      <Dialog open={showBackupDialog} onOpenChange={setShowBackupDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Ambulance Delay Detected
            </DialogTitle>
            <DialogDescription>
              Primary ambulance is experiencing delays. Backup ambulance can reach faster.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <p className="font-medium text-red-700">Current: Rescue 1</p>
              <p className="text-sm text-red-600">ETA: 15 min (delayed by 7 min)</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="font-medium text-green-700">Backup: Rescue 4</p>
              <p className="text-sm text-green-600">ETA: 8 min (faster by 7 min)</p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowBackupDialog(false)}>Keep Current</Button>
            <Button onClick={() => setShowBackupDialog(false)}>Switch to Backup</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Hospital Switch Dialog */}
      <Dialog open={showHospitalDialog} onOpenChange={setShowHospitalDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-orange-500" />
              Hospital Capacity Alert
            </DialogTitle>
            <DialogDescription>
              Primary hospital is nearing capacity. Alternative hospital available.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <p className="font-medium text-red-700">Current: University Hospital</p>
              <p className="text-sm text-red-600">ER: 68/70 capacity - DIVERTING</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="font-medium text-green-700">Alternative: St. Mary's Hospital</p>
              <p className="text-sm text-green-600">ER: 18/35 capacity - ACCEPTING</p>
              <p className="text-xs text-green-600 mt-1">Additional 5 min travel time</p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowHospitalDialog(false)}>Keep Current</Button>
            <Button onClick={() => setShowHospitalDialog(false)}>Switch Hospital</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default EmergencyDetails;
