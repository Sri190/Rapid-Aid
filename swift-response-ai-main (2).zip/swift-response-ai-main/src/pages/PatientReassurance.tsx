import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  Clock,
  CheckCircle,
  User,
  Phone,
  RefreshCw,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  text: string;
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
  isAuto: boolean;
}

const PatientReassurance: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Emergency services have been notified. Help is on the way.',
      timestamp: new Date(Date.now() - 15 * 60000),
      status: 'read',
      isAuto: true,
    },
    {
      id: '2',
      text: 'An ambulance has been dispatched to your location.',
      timestamp: new Date(Date.now() - 10 * 60000),
      status: 'delivered',
      isAuto: true,
    },
    {
      id: '3',
      text: 'The ambulance is currently en route. ETA: 8 minutes.',
      timestamp: new Date(Date.now() - 5 * 60000),
      status: 'delivered',
      isAuto: true,
    },
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [autoMessageEnabled, setAutoMessageEnabled] = useState(true);

  const quickMessages = [
    'Help is on the way. Please stay calm.',
    'The ambulance is just a few minutes away.',
    'Please stay on the line if you can.',
    'Keep the patient comfortable and warm.',
    'Do not move the patient unless necessary.',
  ];

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    const message: Message = {
      id: Date.now().toString(),
      text: newMessage,
      timestamp: new Date(),
      status: 'sent',
      isAuto: false,
    };
    
    setMessages(prev => [...prev, message]);
    setNewMessage('');

    // Simulate delivery
    setTimeout(() => {
      setMessages(prev => prev.map(m => m.id === message.id ? { ...m, status: 'delivered' } : m));
    }, 1500);
  };

  const sendQuickMessage = (text: string) => {
    const message: Message = {
      id: Date.now().toString(),
      text,
      timestamp: new Date(),
      status: 'sent',
      isAuto: false,
    };
    
    setMessages(prev => [...prev, message]);

    setTimeout(() => {
      setMessages(prev => prev.map(m => m.id === message.id ? { ...m, status: 'delivered' } : m));
    }, 1500);
  };

  const statusIcon = (status: Message['status']) => {
    switch (status) {
      case 'sent':
        return <Clock className="w-3 h-3 text-gray-400" />;
      case 'delivered':
        return <CheckCircle className="w-3 h-3 text-blue-500" />;
      case 'read':
        return <CheckCircle className="w-3 h-3 text-green-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Patient Reassurance Console</h1>
          <p className="text-muted-foreground mt-1">Keep callers informed with automated and manual updates</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={autoMessageEnabled}
              onChange={(e) => setAutoMessageEnabled(e.target.checked)}
              className="w-4 h-4 rounded border-gray-300"
            />
            <span className="text-sm">Auto-messages (every 5 min)</span>
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Message Timeline */}
        <div className="lg:col-span-2">
          <Card className="medical-card h-[600px] flex flex-col">
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">John Smith</CardTitle>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      555-XXX-0101
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                  Active Call
                </span>
              </div>
            </CardHeader>
            
            <CardContent className="flex-1 overflow-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={cn(
                    'max-w-[80%] p-4 rounded-2xl',
                    'ml-auto bg-primary text-primary-foreground'
                  )}
                >
                  <p className="text-sm">{message.text}</p>
                  <div className="flex items-center justify-end gap-2 mt-2 text-xs opacity-70">
                    <span>{message.timestamp.toLocaleTimeString()}</span>
                    {statusIcon(message.status)}
                    {message.isAuto && (
                      <span className="px-1.5 py-0.5 bg-white/20 rounded text-xs">Auto</span>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>

            <div className="border-t p-4">
              <div className="flex gap-2">
                <Textarea
                  placeholder="Type a reassurance message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="min-h-[60px] resize-none"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                />
                <Button onClick={handleSendMessage} className="self-end">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Quick Messages */}
        <div className="space-y-4">
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">Quick Messages</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {quickMessages.map((msg, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-3"
                  onClick={() => sendQuickMessage(msg)}
                >
                  <MessageSquare className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">{msg}</span>
                </Button>
              ))}
            </CardContent>
          </Card>

          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">Auto-Message Schedule</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm">Next auto-message</span>
                <span className="font-mono font-medium">2:34</span>
              </div>
              <div className="text-xs text-muted-foreground">
                Auto-messages are sent every 5 minutes to keep the caller informed about the status of their emergency.
              </div>
            </CardContent>
          </Card>

          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">Message Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{messages.length}</div>
                  <div className="text-xs text-muted-foreground">Messages Sent</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {messages.filter(m => m.status === 'delivered' || m.status === 'read').length}
                  </div>
                  <div className="text-xs text-muted-foreground">Delivered</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default PatientReassurance;
