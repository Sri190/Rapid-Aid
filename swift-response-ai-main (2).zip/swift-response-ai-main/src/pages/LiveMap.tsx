import React, { useState } from 'react';
import { useEmergency } from '@/contexts/EmergencyContext';
import { useNavigate } from 'react-router-dom';
import {
  Map,
  Layers,
  Ambulance,
  Building2,
  AlertTriangle,
  Flame,
  Users,
  Navigation,
  ZoomIn,
  ZoomOut,
  Maximize2,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

type MapLayer = 'satellite' | 'normal';

const LiveMap: React.FC = () => {
  const { emergencies, ambulances, hospitals } = useEmergency();
  const navigate = useNavigate();
  const [mapLayer, setMapLayer] = useState<MapLayer>('normal');
  const [zoom, setZoom] = useState(12);
  const [selectedMarker, setSelectedMarker] = useState<string | null>(null);

  const activeEmergencies = emergencies.filter(e => e.status !== 'resolved');

  const markers = [
    ...activeEmergencies.map(e => ({
      id: e.id,
      type: 'emergency' as const,
      position: e.location,
      priority: e.priority,
      label: e.type,
    })),
    ...ambulances.map(a => ({
      id: a.id,
      type: 'ambulance' as const,
      position: a.location,
      status: a.status,
      label: a.callSign,
    })),
    ...hospitals.map(h => ({
      id: h.id,
      type: 'hospital' as const,
      position: h.location,
      status: h.status,
      label: h.name,
    })),
  ];

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4">
      {/* Map Container */}
      <div className="flex-1 relative rounded-2xl overflow-hidden border border-gray-200 shadow-lg">
        {/* Map Background */}
        <div
          className={cn(
            'absolute inset-0 transition-all duration-300',
            mapLayer === 'satellite'
              ? 'bg-gradient-to-br from-gray-800 via-gray-700 to-gray-900'
              : 'bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50'
          )}
        >
          {/* Grid Lines */}
          <div className="absolute inset-0 opacity-20">
            <svg className="w-full h-full">
              <defs>
                <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
                  <path d="M 50 0 L 0 0 0 50" fill="none" stroke={mapLayer === 'satellite' ? '#fff' : '#3b82f6'} strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          {/* Roads Simulation */}
          <svg className="absolute inset-0 w-full h-full opacity-30">
            <path d="M 0 200 Q 300 250 600 200 T 1200 180" stroke={mapLayer === 'satellite' ? '#666' : '#94a3b8'} strokeWidth="4" fill="none" />
            <path d="M 0 400 Q 400 350 800 400 T 1200 380" stroke={mapLayer === 'satellite' ? '#666' : '#94a3b8'} strokeWidth="6" fill="none" />
            <path d="M 200 0 Q 250 300 200 600" stroke={mapLayer === 'satellite' ? '#666' : '#94a3b8'} strokeWidth="3" fill="none" />
            <path d="M 600 0 Q 550 200 600 400 T 650 800" stroke={mapLayer === 'satellite' ? '#666' : '#94a3b8'} strokeWidth="5" fill="none" />
          </svg>

          {/* Route Lines */}
          <svg className="absolute inset-0 w-full h-full">
            <path 
              d="M 400 300 Q 450 350 500 320 T 600 280" 
              stroke="#3b82f6" 
              strokeWidth="4" 
              fill="none" 
              strokeDasharray="10,5"
              className="animate-pulse"
            />
            <path 
              d="M 300 400 L 450 350 L 550 400" 
              stroke="#f59e0b" 
              strokeWidth="3" 
              fill="none" 
              strokeDasharray="8,4"
            />
          </svg>
        </div>

        {/* Markers */}
        <div className="absolute inset-0">
          {markers.map((marker, idx) => {
            const x = 100 + (idx * 150) % 800;
            const y = 100 + Math.floor(idx / 5) * 120 + (idx % 3) * 50;
            
            return (
              <div
                key={marker.id}
                className="absolute cursor-pointer transition-transform hover:scale-110"
                style={{ left: x, top: y }}
                onClick={() => {
                  setSelectedMarker(marker.id);
                  if (marker.type === 'emergency') {
                    navigate(`/emergency/${marker.id}`);
                  } else if (marker.type === 'ambulance') {
                    navigate('/ambulance-tracking');
                  } else {
                    navigate('/hospital-capacity');
                  }
                }}
              >
                <div className={cn(
                  'map-marker',
                  marker.type === 'emergency' && 'bg-red-500 shadow-glow-red',
                  marker.type === 'ambulance' && 'bg-blue-500 shadow-glow-blue',
                  marker.type === 'hospital' && 'bg-green-500'
                )}>
                  {marker.type === 'emergency' && <AlertTriangle className="w-4 h-4 text-white" />}
                  {marker.type === 'ambulance' && <Ambulance className="w-4 h-4 text-white animate-vehicle-move" />}
                  {marker.type === 'hospital' && <Building2 className="w-4 h-4 text-white" />}
                </div>
                {/* Pulse Ring for Emergencies */}
                {marker.type === 'emergency' && (
                  <div className="absolute inset-0 -m-2">
                    <div className="w-12 h-12 rounded-full bg-red-500/30 animate-pulse-ring" />
                  </div>
                )}
                {/* Label */}
                <div className={cn(
                  'absolute left-1/2 -translate-x-1/2 top-10 whitespace-nowrap px-2 py-1 rounded text-xs font-medium',
                  mapLayer === 'satellite' ? 'bg-black/70 text-white' : 'bg-white shadow-md text-gray-700'
                )}>
                  {marker.label}
                </div>
              </div>
            );
          })}
        </div>

        {/* Map Controls */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <Button
            variant="secondary"
            size="icon"
            className="bg-white shadow-md"
            onClick={() => setZoom(Math.min(zoom + 1, 18))}
          >
            <ZoomIn className="w-4 h-4" />
          </Button>
          <Button
            variant="secondary"
            size="icon"
            className="bg-white shadow-md"
            onClick={() => setZoom(Math.max(zoom - 1, 8))}
          >
            <ZoomOut className="w-4 h-4" />
          </Button>
          <Button variant="secondary" size="icon" className="bg-white shadow-md">
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>

        {/* Layer Toggle */}
        <div className="absolute top-4 left-4 bg-white rounded-lg shadow-md p-1 flex gap-1">
          <Button
            variant={mapLayer === 'normal' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setMapLayer('normal')}
          >
            <Map className="w-4 h-4 mr-1" />
            Normal
          </Button>
          <Button
            variant={mapLayer === 'satellite' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setMapLayer('satellite')}
          >
            <Layers className="w-4 h-4 mr-1" />
            Satellite
          </Button>
        </div>

        {/* Zoom Level */}
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-lg text-sm font-medium shadow">
          Zoom: {zoom}x
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-md p-3">
          <div className="text-xs font-semibold mb-2 text-gray-600">Legend</div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded-full" />
              <span className="text-xs">Emergency</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-blue-500 rounded-full" />
              <span className="text-xs">Ambulance</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded-full" />
              <span className="text-xs">Hospital</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-blue-500" />
              <span className="text-xs">Primary Route</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-yellow-500" />
              <span className="text-xs">Alternate Route</span>
            </div>
          </div>
        </div>
      </div>

      {/* Side Panel */}
      <div className="w-80 space-y-4 overflow-auto">
        {/* Active Emergencies */}
        <Card className="medical-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500" />
              Active Emergencies ({activeEmergencies.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {activeEmergencies.slice(0, 4).map(emergency => (
              <div
                key={emergency.id}
                className="p-3 rounded-lg bg-gray-50 hover:bg-gray-100 cursor-pointer transition-colors"
                onClick={() => navigate(`/emergency/${emergency.id}`)}
              >
                <div className="flex items-center gap-2">
                  <div className={cn(
                    'w-2 h-2 rounded-full',
                    emergency.priority === 'high' && 'bg-red-500',
                    emergency.priority === 'medium' && 'bg-yellow-500',
                    emergency.priority === 'low' && 'bg-green-500'
                  )} />
                  <span className="font-medium text-sm">{emergency.type}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1 truncate">
                  {emergency.location.address}
                </p>
                {emergency.eta && (
                  <p className="text-xs text-blue-600 mt-1">ETA: {emergency.eta} min</p>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Fleet Status */}
        <Card className="medical-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Ambulance className="w-4 h-4 text-blue-500" />
              Ambulance Fleet
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {ambulances.map(amb => (
              <div
                key={amb.id}
                className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                onClick={() => navigate('/ambulance-tracking')}
              >
                <div className="flex items-center gap-2">
                  <Ambulance className="w-4 h-4 text-blue-500" />
                  <span className="text-sm font-medium">{amb.callSign}</span>
                </div>
                <span className={cn(
                  'text-xs px-2 py-0.5 rounded-full',
                  amb.status === 'available' && 'bg-green-100 text-green-700',
                  amb.status === 'dispatched' && 'bg-blue-100 text-blue-700',
                  amb.status === 'en-route' && 'bg-purple-100 text-purple-700',
                  amb.status === 'on-scene' && 'bg-orange-100 text-orange-700',
                  amb.status === 'returning' && 'bg-gray-100 text-gray-700'
                )}>
                  {amb.status}
                </span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Traffic Overlay */}
        <Card className="medical-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Navigation className="w-4 h-4 text-orange-500" />
              Traffic Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm">Highway 12</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-700">Heavy</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Main Street</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700">Moderate</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Industrial Park</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700">Clear</span>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-3"
              onClick={() => navigate('/traffic')}
            >
              View Traffic Details
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LiveMap;
