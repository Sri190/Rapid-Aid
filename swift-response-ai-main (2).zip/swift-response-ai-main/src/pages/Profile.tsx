import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { User, Mail, Phone, Shield, Clock, Edit } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Profile: React.FC = () => {
  const { user, getRoleLabel } = useAuth();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <User className="w-7 h-7 text-primary" />
          Profile
        </h1>
        <p className="text-muted-foreground mt-1">Manage your account information</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="medical-card md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Personal Information</CardTitle>
            <Button variant="outline" size="sm">
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">
                  {user?.name.split(' ').map(n => n[0]).join('')}
                </span>
              </div>
              <div>
                <h3 className="text-xl font-semibold">{user?.name}</h3>
                <p className="text-muted-foreground">{user && getRoleLabel(user.role)}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground uppercase">Email</label>
                <p className="font-medium flex items-center gap-2">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  {user?.email}
                </p>
              </div>
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground uppercase">Phone</label>
                <p className="font-medium flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  +1 (555) 123-4567
                </p>
              </div>
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground uppercase">Role</label>
                <p className="font-medium flex items-center gap-2">
                  <Shield className="w-4 h-4 text-muted-foreground" />
                  {user && getRoleLabel(user.role)}
                </p>
              </div>
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground uppercase">Last Login</label>
                <p className="font-medium flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  Today, 08:30 AM
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg">Activity Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">47</div>
              <div className="text-sm text-muted-foreground">Emergencies Handled</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">6.8 min</div>
              <div className="text-sm text-muted-foreground">Avg Response Time</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">98%</div>
              <div className="text-sm text-muted-foreground">Success Rate</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Profile;
