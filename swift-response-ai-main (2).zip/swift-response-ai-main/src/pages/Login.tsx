import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertTriangle, Shield, Ambulance, Building2, Headphones, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const roleOptions: { role: UserRole; label: string; icon: React.ElementType; description: string }[] = [
  {
    role: 'operator',
    label: 'Control Room Operator',
    icon: Headphones,
    description: 'Manage incoming calls, dispatch resources, and coordinate emergency response',
  },
  {
    role: 'ambulance',
    label: 'Rescue Coordinator',
    icon: Ambulance,
    description: 'Track ambulance teams, manage rescue operations, and coordinate field units',
  },
  {
    role: 'hospital',
    label: 'Hospital Admin',
    icon: Building2,
    description: 'Manage hospital capacity, incoming patients, and emergency resources',
  },
];

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) {
      setError('Please select a role');
      return;
    }
    if (!email || !password) {
      setError('Please enter email and password');
      return;
    }

    setIsLoading(true);
    setError('');

    const success = await login(email, password, selectedRole);
    
    if (success) {
      navigate('/dashboard');
    } else {
      setError('Invalid credentials');
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-gray-50 flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-primary p-12 flex-col justify-between relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-blue-800" />
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-7 h-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">ERS</span>
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">
            AI-Assisted Emergency<br />Response System
          </h1>
          <p className="text-blue-100 text-lg max-w-md">
            Intelligent prioritization and resource allocation for faster, smarter emergency response.
          </p>
        </div>

        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-3 text-white/80">
            <Shield className="w-5 h-5" />
            <span>Government-Grade Security</span>
          </div>
          <div className="flex items-center gap-3 text-white/80">
            <AlertTriangle className="w-5 h-5" />
            <span>Real-time Emergency Tracking</span>
          </div>
          <div className="flex items-center gap-3 text-white/80">
            <Ambulance className="w-5 h-5" />
            <span>AI-Powered Resource Dispatch</span>
          </div>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold">Emergency Response System</span>
          </div>

          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-foreground">Welcome Back</h2>
            <p className="text-muted-foreground mt-2">Sign in to access the control center</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Role Selection */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Select Your Role</Label>
              <div className="grid gap-3">
                {roleOptions.map((option) => (
                  <button
                    key={option.role}
                    type="button"
                    onClick={() => setSelectedRole(option.role)}
                    className={cn(
                      'w-full p-4 rounded-xl border-2 transition-all duration-200 text-left flex items-start gap-4',
                      selectedRole === option.role
                        ? 'border-primary bg-primary/5 shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    )}
                  >
                    <div
                      className={cn(
                        'w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0',
                        selectedRole === option.role ? 'bg-primary text-white' : 'bg-gray-100 text-gray-600'
                      )}
                    >
                      <option.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{option.label}</div>
                      <div className="text-sm text-muted-foreground">{option.description}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12"
              />
            </div>

            {/* Password */}
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12"
              />
            </div>

            {error && (
              <div className="text-red-500 text-sm text-center bg-red-50 py-2 rounded-lg">
                {error}
              </div>
            )}

            <Button type="submit" className="w-full h-12 text-base" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Signing In...
                </>
              ) : (
                'Sign In'
              )}
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              Demo: Use any email/password with a selected role
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
