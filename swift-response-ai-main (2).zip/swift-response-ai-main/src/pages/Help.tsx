import React from 'react';
import { HelpCircle, Book, MessageCircle, Phone, FileText, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Help: React.FC = () => {
  const helpTopics = [
    { title: 'Getting Started', description: 'Learn the basics of the emergency response system' },
    { title: 'Dispatch Procedures', description: 'How to properly dispatch and track resources' },
    { title: 'AI Priority System', description: 'Understanding AI-assisted prioritization' },
    { title: 'Backup & Failover', description: 'Managing backup resources and failover protocols' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <HelpCircle className="w-7 h-7 text-primary" />
          Help & Support
        </h1>
        <p className="text-muted-foreground mt-1">Get help and access documentation</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="medical-card text-center p-6 hover:shadow-lg transition-all cursor-pointer">
          <Book className="w-12 h-12 text-blue-500 mx-auto mb-4" />
          <h3 className="font-semibold mb-2">Documentation</h3>
          <p className="text-sm text-muted-foreground">Access system documentation and guides</p>
        </Card>
        <Card className="medical-card text-center p-6 hover:shadow-lg transition-all cursor-pointer">
          <MessageCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
          <h3 className="font-semibold mb-2">Live Chat</h3>
          <p className="text-sm text-muted-foreground">Chat with support team in real-time</p>
        </Card>
        <Card className="medical-card text-center p-6 hover:shadow-lg transition-all cursor-pointer">
          <Phone className="w-12 h-12 text-purple-500 mx-auto mb-4" />
          <h3 className="font-semibold mb-2">Emergency Hotline</h3>
          <p className="text-sm text-muted-foreground">24/7 technical support: 1-800-ERS-HELP</p>
        </Card>
      </div>

      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="text-lg">Popular Help Topics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {helpTopics.map((topic, idx) => (
            <div 
              key={idx} 
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium">{topic.title}</p>
                  <p className="text-sm text-muted-foreground">{topic.description}</p>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-muted-foreground" />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};

export default Help;
