import React from 'react';
import { useEmergency } from '@/contexts/EmergencyContext';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  MapPin,
  Clock,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const ActiveEmergencies: React.FC = () => {
  const { emergencies } = useEmergency();
  const navigate = useNavigate();

  const activeEmergencies = emergencies.filter(e => e.status !== 'resolved');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Active Emergencies</h1>
          <p className="text-muted-foreground mt-1">{activeEmergencies.length} emergencies currently active</p>
        </div>
        <Button variant="outline">
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </Button>
      </div>

      <div className="grid gap-4">
        {activeEmergencies.map((emergency) => (
          <Card 
            key={emergency.id} 
            className="medical-card cursor-pointer hover:shadow-lg transition-all"
            onClick={() => navigate(`/emergency/${emergency.id}`)}
          >
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className={cn(
                  'w-12 h-12 rounded-xl flex items-center justify-center',
                  emergency.priority === 'high' && 'bg-red-100',
                  emergency.priority === 'medium' && 'bg-yellow-100',
                  emergency.priority === 'low' && 'bg-green-100'
                )}>
                  <AlertTriangle className={cn(
                    'w-6 h-6',
                    emergency.priority === 'high' && 'text-red-600',
                    emergency.priority === 'medium' && 'text-yellow-600',
                    emergency.priority === 'low' && 'text-green-600'
                  )} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <h3 className="font-semibold text-lg">{emergency.type}</h3>
                    <span className="text-xs font-mono text-muted-foreground">{emergency.id}</span>
                    <span className={cn(
                      'text-xs px-2 py-1 rounded-full font-medium',
                      emergency.status === 'incoming' && 'bg-yellow-100 text-yellow-700',
                      emergency.status === 'dispatched' && 'bg-blue-100 text-blue-700',
                      emergency.status === 'en-route' && 'bg-purple-100 text-purple-700',
                      emergency.status === 'on-scene' && 'bg-green-100 text-green-700'
                    )}>
                      {emergency.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {emergency.location.address}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {Math.floor((Date.now() - emergency.timeReceived.getTime()) / 60000)}m ago
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-primary">{emergency.priorityScore}</div>
                  <div className="text-xs text-muted-foreground">Priority Score</div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ActiveEmergencies;
