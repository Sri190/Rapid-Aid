import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useEmergency } from '@/contexts/EmergencyContext';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  Phone,
  Ambulance,
  Building2,
  Clock,
  TrendingUp,
  Users,
  Activity,
  ArrowRight,
  MapPin,
  Brain,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { emergencies, ambulances, hospitals, mode } = useEmergency();
  const navigate = useNavigate();

  const activeEmergencies = emergencies.filter(e => e.status !== 'resolved');
  const highPriorityCount = activeEmergencies.filter(e => e.priority === 'high').length;
  const availableAmbulances = ambulances.filter(a => a.status === 'available').length;
  const acceptingHospitals = hospitals.filter(h => h.status === 'accepting').length;

  const stats = [
    {
      label: 'Active Emergencies',
      value: activeEmergencies.length,
      icon: AlertTriangle,
      color: 'text-red-600 bg-red-50',
      trend: '+2 from last hour',
      path: '/active',
    },
    {
      label: 'High Priority',
      value: highPriorityCount,
      icon: Brain,
      color: 'text-orange-600 bg-orange-50',
      trend: 'Requires immediate attention',
      path: '/priority-queue',
    },
    {
      label: 'Available Ambulances',
      value: `${availableAmbulances}/${ambulances.length}`,
      icon: Ambulance,
      color: 'text-blue-600 bg-blue-50',
      trend: '2 returning soon',
      path: '/ambulance-tracking',
    },
    {
      label: 'Hospital Capacity',
      value: `${acceptingHospitals}/${hospitals.length}`,
      icon: Building2,
      color: 'text-green-600 bg-green-50',
      trend: 'accepting patients',
      path: '/hospital-capacity',
    },
  ];

  const recentEmergencies = emergencies.slice(0, 5);

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Welcome Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Welcome back, {user?.name?.split(' ')[0]}
          </h1>
          <p className="text-muted-foreground mt-1">
            Here's what's happening in your emergency response network
          </p>
        </div>
        <div className={cn('mode-indicator', `mode-${mode}`)}>
          {mode.charAt(0).toUpperCase() + mode.slice(1)} Mode
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card
            key={stat.label}
            className="medical-card cursor-pointer hover:shadow-lg transition-all duration-200"
            onClick={() => navigate(stat.path)}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className={cn('p-3 rounded-xl', stat.color)}>
                  <stat.icon className="w-6 h-6" />
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="mt-4">
                <div className="text-3xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm font-medium text-foreground mt-1">{stat.label}</div>
                <div className="text-xs text-muted-foreground mt-1">{stat.trend}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Emergencies */}
        <Card className="medical-card lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold">Recent Emergencies</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate('/active')}>
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentEmergencies.map((emergency) => (
                <div
                  key={emergency.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-gray-100 cursor-pointer transition-colors"
                  onClick={() => navigate(`/emergency/${emergency.id}`)}
                >
                  <div
                    className={cn(
                      'w-3 h-3 rounded-full',
                      emergency.priority === 'high' && 'bg-red-500',
                      emergency.priority === 'medium' && 'bg-yellow-500',
                      emergency.priority === 'low' && 'bg-green-500'
                    )}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{emergency.type}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-gray-200 text-gray-600">
                        {emergency.id}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{emergency.location.address}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn(
                      'text-xs font-medium px-2 py-1 rounded-full',
                      emergency.status === 'incoming' && 'bg-yellow-100 text-yellow-700',
                      emergency.status === 'dispatched' && 'bg-blue-100 text-blue-700',
                      emergency.status === 'en-route' && 'bg-purple-100 text-purple-700',
                      emergency.status === 'on-scene' && 'bg-green-100 text-green-700',
                      emergency.status === 'resolved' && 'bg-gray-100 text-gray-700'
                    )}>
                      {emergency.status}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {Math.floor((Date.now() - emergency.timeReceived.getTime()) / 60000)}m ago
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="default"
              className="w-full justify-start gap-3 h-12"
              onClick={() => navigate('/incoming')}
            >
              <Phone className="w-5 h-5" />
              View Incoming Calls
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-3 h-12"
              onClick={() => navigate('/map')}
            >
              <MapPin className="w-5 h-5" />
              Open Live Map
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-3 h-12"
              onClick={() => navigate('/priority-queue')}
            >
              <Brain className="w-5 h-5" />
              AI Priority Queue
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-3 h-12"
              onClick={() => navigate('/ambulance-tracking')}
            >
              <Ambulance className="w-5 h-5" />
              Track Ambulances
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-3 h-12"
              onClick={() => navigate('/hospital-capacity')}
            >
              <Building2 className="w-5 h-5" />
              Hospital Status
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Resource Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Ambulance Status */}
        <Card className="medical-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Ambulance Fleet</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {ambulances.slice(0, 4).map((amb) => (
                <div
                  key={amb.id}
                  className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                  onClick={() => navigate('/ambulance-tracking')}
                >
                  <div className="flex items-center gap-2">
                    <Ambulance className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium">{amb.callSign}</span>
                  </div>
                  <span className={cn(
                    'text-xs px-2 py-0.5 rounded-full',
                    amb.status === 'available' && 'bg-green-100 text-green-700',
                    amb.status === 'dispatched' && 'bg-blue-100 text-blue-700',
                    amb.status === 'en-route' && 'bg-purple-100 text-purple-700',
                    amb.status === 'on-scene' && 'bg-orange-100 text-orange-700',
                    amb.status === 'returning' && 'bg-gray-100 text-gray-700'
                  )}>
                    {amb.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Hospital Status */}
        <Card className="medical-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Hospital Network</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {hospitals.map((hospital) => (
                <div
                  key={hospital.id}
                  className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                  onClick={() => navigate('/hospital-capacity')}
                >
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium truncate max-w-[120px]">{hospital.name}</span>
                  </div>
                  <span className={cn(
                    'text-xs px-2 py-0.5 rounded-full',
                    hospital.status === 'accepting' && 'bg-green-100 text-green-700',
                    hospital.status === 'limited' && 'bg-yellow-100 text-yellow-700',
                    hospital.status === 'diverting' && 'bg-red-100 text-red-700'
                  )}>
                    {hospital.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card className="medical-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">System Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">AI Engine</span>
                <div className="flex items-center gap-2">
                  <div className="status-dot status-dot-active" />
                  <span className="text-xs text-green-600">Operational</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">GPS Tracking</span>
                <div className="flex items-center gap-2">
                  <div className="status-dot status-dot-active" />
                  <span className="text-xs text-green-600">Active</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Communication</span>
                <div className="flex items-center gap-2">
                  <div className="status-dot status-dot-active" />
                  <span className="text-xs text-green-600">Connected</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Backup Systems</span>
                <div className="flex items-center gap-2">
                  <div className="status-dot status-dot-active" />
                  <span className="text-xs text-green-600">Standby</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
