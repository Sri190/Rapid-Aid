import React, { useState, useEffect } from 'react';
import { useEmergency } from '@/contexts/EmergencyContext';
import { useNavigate } from 'react-router-dom';
import {
  Phone,
  MapPin,
  Clock,
  User,
  AlertTriangle,
  Activity,
  Volume2,
  ChevronRight,
  PhoneIncoming,
  Mic,
  Users,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface IncomingCall {
  id: string;
  callerName: string;
  phone: string;
  location: string;
  coordinates: { lat: number; lng: number };
  timeReceived: Date;
  duration: number;
  category: string;
  emotionState: 'calm' | 'anxious' | 'panic';
  transcript: string;
  isActive: boolean;
}

const mockIncomingCalls: IncomingCall[] = [
  {
    id: 'CALL-001',
    callerName: 'Anonymous',
    phone: '555-XXX-0142',
    location: '789 Oak Avenue, Downtown',
    coordinates: { lat: 40.7128, lng: -74.006 },
    timeReceived: new Date(),
    duration: 45,
    category: 'Medical Emergency',
    emotionState: 'panic',
    transcript: 'Please help! My mother just collapsed in the kitchen. She\'s not responding to anything I say. I think she might have had a stroke...',
    isActive: true,
  },
  {
    id: 'CALL-002',
    callerName: 'John Peterson',
    phone: '555-XXX-8821',
    location: '45 Industrial Road',
    coordinates: { lat: 40.7282, lng: -73.994 },
    timeReceived: new Date(Date.now() - 2 * 60000),
    duration: 120,
    category: 'Fire',
    emotionState: 'anxious',
    transcript: 'There\'s smoke coming from the warehouse next door. I can see flames through the windows. I don\'t think anyone is inside but I\'m not sure.',
    isActive: false,
  },
  {
    id: 'CALL-003',
    callerName: 'Security Guard',
    phone: '555-XXX-3301',
    location: 'Central Mall, Floor 2',
    coordinates: { lat: 40.7489, lng: -73.968 },
    timeReceived: new Date(Date.now() - 5 * 60000),
    duration: 90,
    category: 'Accident',
    emotionState: 'calm',
    transcript: 'We have a slip and fall incident here at the mall. An elderly woman fell on the escalator. She\'s conscious but complaining of hip pain.',
    isActive: false,
  },
  {
    id: 'CALL-004',
    callerName: 'Restaurant Staff',
    phone: '555-XXX-7744',
    location: '567 Restaurant Row',
    coordinates: { lat: 40.7614, lng: -73.977 },
    timeReceived: new Date(Date.now() - 1 * 60000),
    duration: 60,
    category: 'Medical Emergency',
    emotionState: 'anxious',
    transcript: 'A customer is having a severe allergic reaction. We gave him an EpiPen but he still looks very bad. His face is swelling.',
    isActive: true,
  },
];

const IncomingRequests: React.FC = () => {
  const navigate = useNavigate();
  const [calls, setCalls] = useState<IncomingCall[]>(mockIncomingCalls);
  const [selectedCall, setSelectedCall] = useState<IncomingCall | null>(null);
  const [waveformValues, setWaveformValues] = useState<number[]>(Array(30).fill(0));

  // Simulate waveform animation
  useEffect(() => {
    const interval = setInterval(() => {
      setWaveformValues(prev => 
        prev.map(() => Math.random() * 100)
      );
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const emotionColors = {
    calm: 'bg-green-100 text-green-700',
    anxious: 'bg-yellow-100 text-yellow-700',
    panic: 'bg-red-100 text-red-700',
  };

  const handleAcceptCall = (call: IncomingCall) => {
    navigate('/emergency-details', { state: { call } });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Incoming Emergency Requests</h1>
          <p className="text-muted-foreground mt-1">Real-time call intake and triage</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="status-dot status-dot-active" />
          <span className="text-sm text-green-600 font-medium">System Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Call List */}
        <div className="lg:col-span-2 space-y-4">
          {calls.map((call) => (
            <Card
              key={call.id}
              className={cn(
                'medical-card cursor-pointer transition-all duration-200 hover:shadow-lg',
                call.isActive && 'ring-2 ring-red-500 ring-offset-2',
                selectedCall?.id === call.id && 'bg-blue-50'
              )}
              onClick={() => setSelectedCall(call)}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  {/* Call Icon */}
                  <div className={cn(
                    'w-12 h-12 rounded-xl flex items-center justify-center',
                    call.isActive ? 'bg-red-100 animate-pulse' : 'bg-gray-100'
                  )}>
                    {call.isActive ? (
                      <PhoneIncoming className="w-6 h-6 text-red-600" />
                    ) : (
                      <Phone className="w-6 h-6 text-gray-600" />
                    )}
                  </div>

                  {/* Call Details */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-semibold text-lg">{call.category}</span>
                      <span className={cn('text-xs px-2 py-0.5 rounded-full', emotionColors[call.emotionState])}>
                        {call.emotionState}
                      </span>
                      {call.isActive && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-700 animate-pulse">
                          LIVE
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <User className="w-4 h-4" />
                        <span>{call.callerName}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Phone className="w-4 h-4" />
                        <span>{call.phone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        <span className="truncate">{call.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        <span>{Math.floor(call.duration / 60)}:{(call.duration % 60).toString().padStart(2, '0')}</span>
                      </div>
                    </div>

                    {/* Waveform for active calls */}
                    {call.isActive && (
                      <div className="mt-4 flex items-center gap-1 h-8 bg-gray-100 rounded-lg p-2">
                        {waveformValues.map((value, idx) => (
                          <div
                            key={idx}
                            className="w-1 bg-red-500 rounded-full transition-all duration-100"
                            style={{ height: `${20 + value * 0.6}%` }}
                          />
                        ))}
                        <Volume2 className="w-4 h-4 ml-2 text-red-500" />
                      </div>
                    )}

                    {/* Transcript Preview */}
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                        <Mic className="w-3 h-3" />
                        <span>Live Transcript</span>
                      </div>
                      <p className="text-sm text-foreground italic">"{call.transcript}"</p>
                    </div>
                  </div>

                  {/* Action */}
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAcceptCall(call);
                    }}
                    className={cn(
                      call.isActive ? 'bg-red-600 hover:bg-red-700' : ''
                    )}
                  >
                    {call.isActive ? 'Accept Call' : 'View Details'}
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call Details Panel */}
        <div className="space-y-4">
          <Card className="medical-card sticky top-4">
            <CardHeader>
              <CardTitle className="text-lg">Call Details</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedCall ? (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-muted-foreground uppercase">Caller</label>
                    <p className="font-medium">{selectedCall.callerName}</p>
                    <p className="text-sm text-muted-foreground">{selectedCall.phone}</p>
                  </div>

                  <div>
                    <label className="text-xs text-muted-foreground uppercase">Location</label>
                    <p className="font-medium">{selectedCall.location}</p>
                    <div className="mt-2 h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                      <div className="text-center">
                        <MapPin className="w-8 h-8 text-red-500 mx-auto" />
                        <p className="text-xs text-muted-foreground mt-1">
                          {selectedCall.coordinates.lat.toFixed(4)}, {selectedCall.coordinates.lng.toFixed(4)}
                        </p>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full mt-2"
                      onClick={() => navigate('/map')}
                    >
                      Open in Map
                    </Button>
                  </div>

                  <div>
                    <label className="text-xs text-muted-foreground uppercase">Emotion State</label>
                    <div className={cn('mt-1 px-3 py-2 rounded-lg text-center font-medium', emotionColors[selectedCall.emotionState])}>
                      {selectedCall.emotionState.charAt(0).toUpperCase() + selectedCall.emotionState.slice(1)}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-muted-foreground uppercase">Full Transcript</label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-lg text-sm max-h-40 overflow-auto">
                      {selectedCall.transcript}
                    </div>
                  </div>

                  <div className="pt-4 space-y-2">
                    <Button 
                      className="w-full" 
                      onClick={() => handleAcceptCall(selectedCall)}
                    >
                      Create Emergency Request
                    </Button>
                    <Button variant="outline" className="w-full">
                      Transfer Call
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Phone className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>Select a call to view details</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="medical-card">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">{calls.filter(c => c.isActive).length}</div>
                  <div className="text-xs text-muted-foreground">Active Calls</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{calls.length}</div>
                  <div className="text-xs text-muted-foreground">In Queue</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">2:34</div>
                  <div className="text-xs text-muted-foreground">Avg Wait Time</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">98%</div>
                  <div className="text-xs text-muted-foreground">Answer Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default IncomingRequests;
