import React from 'react';
import {
  Activity,
  Ambulance,
  Building2,
  Flame,
  Users,
  Truck,
  Wrench,
  CheckCircle,
  AlertTriangle,
  XCircle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

const Resources: React.FC = () => {
  const resources = [
    {
      category: 'Ambulances',
      icon: Ambulance,
      color: 'text-blue-600 bg-blue-100',
      total: 12,
      available: 4,
      dispatched: 5,
      maintenance: 3,
    },
    {
      category: 'Fire Engines',
      icon: Flame,
      color: 'text-red-600 bg-red-100',
      total: 8,
      available: 5,
      dispatched: 2,
      maintenance: 1,
    },
    {
      category: 'Rescue Teams',
      icon: Users,
      color: 'text-purple-600 bg-purple-100',
      total: 6,
      available: 3,
      dispatched: 2,
      maintenance: 1,
    },
    {
      category: 'Support Vehicles',
      icon: Truck,
      color: 'text-orange-600 bg-orange-100',
      total: 10,
      available: 7,
      dispatched: 2,
      maintenance: 1,
    },
  ];

  const equipment = [
    { name: 'Defibrillators', available: 24, total: 30 },
    { name: 'Stretchers', available: 18, total: 20 },
    { name: 'Oxygen Tanks', available: 45, total: 50 },
    { name: 'First Aid Kits', available: 95, total: 100 },
    { name: 'Trauma Kits', available: 12, total: 15 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Resource Status</h1>
          <p className="text-muted-foreground mt-1">Real-time overview of all emergency resources</p>
        </div>
        <div className="flex items-center gap-2 bg-green-50 px-4 py-2 rounded-lg">
          <Activity className="w-4 h-4 text-green-600" />
          <span className="text-sm font-medium text-green-700">System Operational</span>
        </div>
      </div>

      {/* Vehicle Resources */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {resources.map((resource) => (
          <Card key={resource.category} className="medical-card">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', resource.color)}>
                  <resource.icon className="w-5 h-5" />
                </div>
                <CardTitle className="text-lg">{resource.category}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground mb-4">
                {resource.available}/{resource.total}
                <span className="text-sm font-normal text-muted-foreground ml-2">available</span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Available
                  </span>
                  <span className="font-medium">{resource.available}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-blue-500" />
                    Dispatched
                  </span>
                  <span className="font-medium">{resource.dispatched}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-orange-500" />
                    Maintenance
                  </span>
                  <span className="font-medium">{resource.maintenance}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Equipment Status */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="text-lg">Equipment Inventory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {equipment.map((item) => (
              <div key={item.name} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{item.name}</span>
                  <span className="text-muted-foreground">{item.available}/{item.total}</span>
                </div>
                <Progress value={(item.available / item.total) * 100} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Staff Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-500" />
              Paramedics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">24</div>
            <div className="text-sm text-muted-foreground">On duty</div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="p-2 bg-green-50 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600">18</div>
                <div className="text-xs text-muted-foreground">Available</div>
              </div>
              <div className="p-2 bg-blue-50 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">6</div>
                <div className="text-xs text-muted-foreground">On Call</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Flame className="w-5 h-5 text-red-500" />
              Firefighters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">32</div>
            <div className="text-sm text-muted-foreground">On duty</div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="p-2 bg-green-50 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600">28</div>
                <div className="text-xs text-muted-foreground">Available</div>
              </div>
              <div className="p-2 bg-blue-50 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">4</div>
                <div className="text-xs text-muted-foreground">On Call</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Activity className="w-5 h-5 text-purple-500" />
              Dispatchers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">8</div>
            <div className="text-sm text-muted-foreground">On duty</div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="p-2 bg-green-50 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600">6</div>
                <div className="text-xs text-muted-foreground">Active</div>
              </div>
              <div className="p-2 bg-yellow-50 rounded-lg text-center">
                <div className="text-lg font-bold text-yellow-600">2</div>
                <div className="text-xs text-muted-foreground">Break</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Resources;
