import React from 'react';
import { TrafficCone, AlertTriangle, Clock, MapPin } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const Traffic: React.FC = () => {
  const trafficData = [
    { road: 'Highway 12', status: 'heavy', delay: '15 min', incident: 'Vehicle collision' },
    { road: 'Main Street', status: 'moderate', delay: '5 min', incident: null },
    { road: 'Industrial Park Rd', status: 'clear', delay: '0 min', incident: null },
    { road: 'Downtown Core', status: 'moderate', delay: '8 min', incident: 'Road work' },
    { road: 'Hospital Way', status: 'clear', delay: '0 min', incident: null },
  ];

  const statusColors = {
    clear: 'bg-green-100 text-green-700 border-green-200',
    moderate: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    heavy: 'bg-red-100 text-red-700 border-red-200',
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <TrafficCone className="w-7 h-7 text-primary" />
          Traffic Intelligence
        </h1>
        <p className="text-muted-foreground mt-1">Real-time traffic conditions affecting emergency routes</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="medical-card bg-green-50 border-green-100">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-green-600">3</div>
            <div className="text-sm text-green-700">Clear Routes</div>
          </CardContent>
        </Card>
        <Card className="medical-card bg-yellow-50 border-yellow-100">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-yellow-600">2</div>
            <div className="text-sm text-yellow-700">Moderate Traffic</div>
          </CardContent>
        </Card>
        <Card className="medical-card bg-red-50 border-red-100">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-red-600">1</div>
            <div className="text-sm text-red-700">Heavy Traffic</div>
          </CardContent>
        </Card>
      </div>

      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="text-lg">Traffic Conditions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {trafficData.map((road, idx) => (
            <div 
              key={idx} 
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center gap-4">
                <MapPin className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">{road.road}</p>
                  {road.incident && (
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      {road.incident}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  +{road.delay}
                </div>
                <span className={cn(
                  'px-3 py-1 rounded-full text-xs font-medium border',
                  statusColors[road.status as keyof typeof statusColors]
                )}>
                  {road.status}
                </span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};

export default Traffic;
