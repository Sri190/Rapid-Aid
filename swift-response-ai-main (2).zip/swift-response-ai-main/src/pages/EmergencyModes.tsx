import React from 'react';
import { useEmergency, EmergencyMode } from '@/contexts/EmergencyContext';
import { Shield, AlertTriangle, Activity, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const EmergencyModes: React.FC = () => {
  const { mode, setMode } = useEmergency();

  const modes = [
    {
      id: 'normal' as EmergencyMode,
      label: 'Normal Operations',
      description: 'Standard emergency response protocols. All systems operating at normal capacity.',
      icon: Activity,
      color: 'bg-green-100 text-green-700 border-green-200',
      features: ['Standard dispatch times', 'Normal resource allocation', 'Regular staffing levels'],
    },
    {
      id: 'peak' as EmergencyMode,
      label: 'Peak Hour Mode',
      description: 'Elevated response mode for high-volume periods. Additional resources activated.',
      icon: AlertTriangle,
      color: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      features: ['Faster dispatch priority', 'Backup units on standby', 'Extended shift coverage'],
    },
    {
      id: 'disaster' as EmergencyMode,
      label: 'Disaster Mode',
      description: 'Maximum emergency protocols activated. All available resources mobilized.',
      icon: Zap,
      color: 'bg-red-100 text-red-700 border-red-200',
      features: ['All units activated', 'Mutual aid requested', 'Emergency triage protocols'],
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Shield className="w-7 h-7 text-primary" />
            Emergency Modes
          </h1>
          <p className="text-muted-foreground mt-1">Configure system-wide emergency response levels</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {modes.map((m) => (
          <Card 
            key={m.id} 
            className={cn(
              'medical-card cursor-pointer transition-all duration-200',
              mode === m.id && 'ring-2 ring-primary ring-offset-2'
            )}
            onClick={() => setMode(m.id)}
          >
            <CardHeader>
              <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center mb-3', m.color)}>
                <m.icon className="w-6 h-6" />
              </div>
              <CardTitle className="text-lg">{m.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{m.description}</p>
              <ul className="space-y-2">
                {m.features.map((feature, idx) => (
                  <li key={idx} className="text-sm flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button 
                className="w-full mt-4" 
                variant={mode === m.id ? 'default' : 'outline'}
              >
                {mode === m.id ? 'Currently Active' : 'Activate'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EmergencyModes;
