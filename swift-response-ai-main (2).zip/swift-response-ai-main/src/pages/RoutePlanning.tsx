import React from 'react';
import { Route, Navigation, Clock, MapPin, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const RoutePlanning: React.FC = () => {
  const routes = [
    {
      id: 1,
      name: 'Highway 12 → Main St → City General',
      type: 'primary',
      distance: '4.2 km',
      eta: '8 min',
      traffic: 'clear',
    },
    {
      id: 2,
      name: 'Industrial Rd → Oak Ave → City General',
      type: 'alternate',
      distance: '5.8 km',
      eta: '12 min',
      traffic: 'moderate',
    },
    {
      id: 3,
      name: 'Bypass Route → Hospital Way',
      type: 'backup',
      distance: '7.1 km',
      eta: '15 min',
      traffic: 'heavy',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Route className="w-7 h-7 text-primary" />
            Route Planning
          </h1>
          <p className="text-muted-foreground mt-1">Optimize emergency response routes</p>
        </div>
        <Button>
          <Navigation className="w-4 h-4 mr-2" />
          Calculate New Route
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Route Map Placeholder */}
        <Card className="medical-card h-96">
          <CardContent className="p-0 h-full">
            <div className="w-full h-full bg-gradient-to-br from-blue-50 to-green-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-primary/30 mx-auto mb-4" />
                <p className="text-muted-foreground">Route visualization</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Route Options */}
        <div className="space-y-4">
          {routes.map((route) => (
            <Card 
              key={route.id} 
              className={cn(
                'medical-card cursor-pointer hover:shadow-lg transition-all',
                route.type === 'primary' && 'ring-2 ring-primary ring-offset-2'
              )}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={cn(
                        'text-xs px-2 py-1 rounded-full font-medium',
                        route.type === 'primary' && 'bg-blue-100 text-blue-700',
                        route.type === 'alternate' && 'bg-yellow-100 text-yellow-700',
                        route.type === 'backup' && 'bg-gray-100 text-gray-700'
                      )}>
                        {route.type}
                      </span>
                      <span className={cn(
                        'text-xs px-2 py-1 rounded-full',
                        route.traffic === 'clear' && 'bg-green-100 text-green-700',
                        route.traffic === 'moderate' && 'bg-yellow-100 text-yellow-700',
                        route.traffic === 'heavy' && 'bg-red-100 text-red-700'
                      )}>
                        {route.traffic} traffic
                      </span>
                    </div>
                    <p className="font-medium">{route.name}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                      <span>{route.distance}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        ETA: {route.eta}
                      </span>
                    </div>
                  </div>
                  <Button variant={route.type === 'primary' ? 'default' : 'outline'} size="sm">
                    {route.type === 'primary' ? 'Active' : 'Select'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoutePlanning;
