import React, { useState } from 'react';
import { useEmergency } from '@/contexts/EmergencyContext';
import { useNavigate } from 'react-router-dom';
import {
  Brain,
  AlertTriangle,
  Clock,
  Users,
  Truck,
  MapPin,
  ChevronRight,
  Info,
  TrendingUp,
  Activity,
  HelpCircle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface PriorityBreakdown {
  severity: number;
  responseTimeRisk: number;
  resourceAvailability: number;
  distanceFactor: number;
}

const PriorityQueue: React.FC = () => {
  const { emergencies } = useEmergency();
  const navigate = useNavigate();
  const [selectedEmergency, setSelectedEmergency] = useState<string | null>(null);

  // Sort by priority score descending
  const sortedEmergencies = [...emergencies]
    .filter(e => e.status !== 'resolved')
    .sort((a, b) => b.priorityScore - a.priorityScore);

  // Mock AI breakdown calculations
  const getBreakdown = (emergency: typeof emergencies[0]): PriorityBreakdown => ({
    severity: emergency.severity * 10,
    responseTimeRisk: Math.min(100, (Date.now() - emergency.timeReceived.getTime()) / 600),
    resourceAvailability: 70 + Math.random() * 30,
    distanceFactor: 60 + Math.random() * 40,
  });

  const factorDescriptions = {
    severity: 'Based on emergency type, number of people affected, and caller assessment',
    responseTimeRisk: 'Time elapsed since call received - longer wait increases priority',
    resourceAvailability: 'Current availability of ambulances, equipment, and hospital capacity',
    distanceFactor: 'Distance from nearest available resources to incident location',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Brain className="w-7 h-7 text-primary" />
            AI Priority Queue
          </h1>
          <p className="text-muted-foreground mt-1">
            Intelligent emergency prioritization with explainable AI scoring
          </p>
        </div>
        <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-lg">
          <Activity className="w-4 h-4 text-blue-600" />
          <span className="text-sm font-medium text-blue-700">AI Engine Active</span>
        </div>
      </div>

      {/* Priority Formula Card */}
      <Card className="medical-card bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-100">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">Priority Score Formula</h3>
              <div className="mt-3 p-4 bg-white rounded-lg font-mono text-sm">
                Priority Score = <span className="text-red-600">0.4 × Severity</span> + 
                <span className="text-orange-600"> 0.3 × Response Time Risk</span> + 
                <span className="text-blue-600"> 0.2 × Resource Availability</span> + 
                <span className="text-green-600"> 0.1 × Distance Factor</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Our AI continuously recalculates priorities based on real-time data. All decisions are explainable and require human approval.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Priority List */}
        <div className="lg:col-span-2 space-y-4">
          {sortedEmergencies.map((emergency, index) => {
            const breakdown = getBreakdown(emergency);
            const isSelected = selectedEmergency === emergency.id;

            return (
              <Card
                key={emergency.id}
                className={cn(
                  'medical-card cursor-pointer transition-all duration-200',
                  isSelected && 'ring-2 ring-primary ring-offset-2'
                )}
                onClick={() => setSelectedEmergency(emergency.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    {/* Rank Badge */}
                    <div className={cn(
                      'w-10 h-10 rounded-full flex items-center justify-center font-bold text-white',
                      index === 0 && 'bg-red-500',
                      index === 1 && 'bg-orange-500',
                      index === 2 && 'bg-yellow-500',
                      index > 2 && 'bg-gray-400'
                    )}>
                      #{index + 1}
                    </div>

                    {/* Emergency Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="font-semibold text-lg">{emergency.type}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">
                          {emergency.id}
                        </span>
                        <span className={cn(
                          'text-xs font-semibold px-2 py-1 rounded-full',
                          emergency.priority === 'high' && 'priority-badge-high',
                          emergency.priority === 'medium' && 'priority-badge-medium',
                          emergency.priority === 'low' && 'priority-badge-low'
                        )}>
                          {emergency.priority.toUpperCase()}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-4 text-sm mb-4">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          <span className="truncate">{emergency.location.address}</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Users className="w-4 h-4" />
                          <span>{emergency.peopleAffected} affected</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          <span>{Math.floor((Date.now() - emergency.timeReceived.getTime()) / 60000)}m ago</span>
                        </div>
                      </div>

                      {/* Priority Score Bar */}
                      <div className="flex items-center gap-4">
                        <div className="flex-1">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-medium">Priority Score</span>
                            <span className="font-bold text-primary">{emergency.priorityScore}/100</span>
                          </div>
                          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className={cn(
                                'h-full rounded-full transition-all duration-500',
                                emergency.priorityScore >= 80 && 'bg-red-500',
                                emergency.priorityScore >= 60 && emergency.priorityScore < 80 && 'bg-orange-500',
                                emergency.priorityScore >= 40 && emergency.priorityScore < 60 && 'bg-yellow-500',
                                emergency.priorityScore < 40 && 'bg-green-500'
                              )}
                              style={{ width: `${emergency.priorityScore}%` }}
                            />
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/emergency/${emergency.id}`);
                          }}
                        >
                          View Details
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>

                      {/* Expanded AI Breakdown */}
                      {isSelected && (
                        <div className="mt-4 p-4 bg-gray-50 rounded-xl animate-fade-in-up">
                          <div className="flex items-center gap-2 mb-3">
                            <HelpCircle className="w-4 h-4 text-primary" />
                            <span className="font-medium text-sm">Why this priority?</span>
                          </div>
                          
                          <TooltipProvider>
                            <div className="space-y-3">
                              <div>
                                <div className="flex justify-between text-xs mb-1">
                                  <Tooltip>
                                    <TooltipTrigger className="flex items-center gap-1 cursor-help">
                                      <span className="text-red-600 font-medium">Severity (40%)</span>
                                      <Info className="w-3 h-3" />
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="max-w-xs">{factorDescriptions.severity}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                  <span>{Math.round(breakdown.severity)}%</span>
                                </div>
                                <Progress value={breakdown.severity} className="h-2 bg-red-100" />
                              </div>

                              <div>
                                <div className="flex justify-between text-xs mb-1">
                                  <Tooltip>
                                    <TooltipTrigger className="flex items-center gap-1 cursor-help">
                                      <span className="text-orange-600 font-medium">Response Time Risk (30%)</span>
                                      <Info className="w-3 h-3" />
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="max-w-xs">{factorDescriptions.responseTimeRisk}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                  <span>{Math.round(breakdown.responseTimeRisk)}%</span>
                                </div>
                                <Progress value={breakdown.responseTimeRisk} className="h-2 bg-orange-100" />
                              </div>

                              <div>
                                <div className="flex justify-between text-xs mb-1">
                                  <Tooltip>
                                    <TooltipTrigger className="flex items-center gap-1 cursor-help">
                                      <span className="text-blue-600 font-medium">Resource Availability (20%)</span>
                                      <Info className="w-3 h-3" />
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="max-w-xs">{factorDescriptions.resourceAvailability}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                  <span>{Math.round(breakdown.resourceAvailability)}%</span>
                                </div>
                                <Progress value={breakdown.resourceAvailability} className="h-2 bg-blue-100" />
                              </div>

                              <div>
                                <div className="flex justify-between text-xs mb-1">
                                  <Tooltip>
                                    <TooltipTrigger className="flex items-center gap-1 cursor-help">
                                      <span className="text-green-600 font-medium">Distance Factor (10%)</span>
                                      <Info className="w-3 h-3" />
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="max-w-xs">{factorDescriptions.distanceFactor}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                  <span>{Math.round(breakdown.distanceFactor)}%</span>
                                </div>
                                <Progress value={breakdown.distanceFactor} className="h-2 bg-green-100" />
                              </div>
                            </div>
                          </TooltipProvider>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Stats Panel */}
        <div className="space-y-4">
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">Queue Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                <span className="text-sm font-medium text-red-700">High Priority</span>
                <span className="text-2xl font-bold text-red-600">
                  {sortedEmergencies.filter(e => e.priority === 'high').length}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                <span className="text-sm font-medium text-yellow-700">Medium Priority</span>
                <span className="text-2xl font-bold text-yellow-600">
                  {sortedEmergencies.filter(e => e.priority === 'medium').length}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium text-green-700">Low Priority</span>
                <span className="text-2xl font-bold text-green-600">
                  {sortedEmergencies.filter(e => e.priority === 'low').length}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-lg">AI Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 text-blue-700 font-medium text-sm mb-1">
                  <TrendingUp className="w-4 h-4" />
                  Peak Hour Alert
                </div>
                <p className="text-xs text-blue-600">
                  Increased call volume detected. Consider activating additional resources.
                </p>
              </div>
              <div className="p-3 bg-orange-50 rounded-lg">
                <div className="flex items-center gap-2 text-orange-700 font-medium text-sm mb-1">
                  <AlertTriangle className="w-4 h-4" />
                  Resource Warning
                </div>
                <p className="text-xs text-orange-600">
                  Only 2 ambulances available. 3 currently en-route.
                </p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <div className="flex items-center gap-2 text-green-700 font-medium text-sm mb-1">
                  <Activity className="w-4 h-4" />
                  Response Efficiency
                </div>
                <p className="text-xs text-green-600">
                  Average response time: 7.2 minutes (within target).
                </p>
              </div>
            </CardContent>
          </Card>

          <Button className="w-full" variant="outline" onClick={() => navigate('/analytics')}>
            View Full Analytics
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PriorityQueue;
