import React from 'react';
import { FileSearch, Filter, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const mockLogs = [
  { timestamp: '14:32:15', level: 'INFO', message: 'Ambulance AMB-01 dispatched to EM-001', user: 'Sarah Johnson' },
  { timestamp: '14:31:42', level: 'WARNING', message: 'Hospital University at 97% ER capacity', user: 'System' },
  { timestamp: '14:30:18', level: 'INFO', message: 'New emergency EM-004 created - Allergic Reaction', user: 'Sarah Johnson' },
  { timestamp: '14:28:55', level: 'INFO', message: 'Backup ambulance recommendation triggered for EM-002', user: 'AI Engine' },
  { timestamp: '14:25:33', level: 'SUCCESS', message: 'Emergency EM-005 marked as resolved', user: 'Michael Chen' },
  { timestamp: '14:22:10', level: 'INFO', message: 'Route recalculated for AMB-03 due to traffic', user: 'System' },
  { timestamp: '14:20:00', level: 'INFO', message: 'Shift handover completed - Team A to Team B', user: 'Admin' },
];

const SystemLogs: React.FC = () => {
  const levelColors = {
    INFO: 'text-blue-600 bg-blue-50',
    WARNING: 'text-yellow-600 bg-yellow-50',
    ERROR: 'text-red-600 bg-red-50',
    SUCCESS: 'text-green-600 bg-green-50',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <FileSearch className="w-7 h-7 text-primary" />
            System Logs
          </h1>
          <p className="text-muted-foreground mt-1">Audit trail and system activity logs</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <Card className="medical-card">
        <CardHeader className="border-b">
          <div className="flex items-center gap-4">
            <Input placeholder="Search logs..." className="max-w-sm" />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            {mockLogs.map((log, idx) => (
              <div key={idx} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start gap-4">
                  <span className="font-mono text-sm text-muted-foreground">{log.timestamp}</span>
                  <span className={cn(
                    'px-2 py-0.5 rounded text-xs font-medium',
                    levelColors[log.level as keyof typeof levelColors]
                  )}>
                    {log.level}
                  </span>
                  <span className="flex-1 text-sm">{log.message}</span>
                  <span className="text-xs text-muted-foreground">{log.user}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SystemLogs;
