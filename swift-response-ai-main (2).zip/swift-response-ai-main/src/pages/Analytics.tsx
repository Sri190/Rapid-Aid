import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  Users,
  Ambulance,
  AlertTriangle,
  Activity,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

const Analytics: React.FC = () => {
  const stats = [
    { label: 'Total Emergencies Today', value: '47', change: '+12%', trend: 'up' },
    { label: 'Avg Response Time', value: '7.2 min', change: '-8%', trend: 'down' },
    { label: 'Resolution Rate', value: '94%', change: '+3%', trend: 'up' },
    { label: 'Active Resources', value: '78%', change: '+5%', trend: 'up' },
  ];

  const emergencyTypes = [
    { type: 'Medical', count: 24, percentage: 51 },
    { type: 'Accident', count: 12, percentage: 26 },
    { type: 'Fire', count: 7, percentage: 15 },
    { type: 'Other', count: 4, percentage: 8 },
  ];

  const hourlyData = [
    { hour: '00:00', calls: 3 },
    { hour: '04:00', calls: 2 },
    { hour: '08:00', calls: 8 },
    { hour: '12:00', calls: 12 },
    { hour: '16:00', calls: 15 },
    { hour: '20:00', calls: 7 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <BarChart3 className="w-7 h-7 text-primary" />
            Analytics & Insights
          </h1>
          <p className="text-muted-foreground mt-1">Performance metrics and operational insights</p>
        </div>
      </div>

      {/* Key Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.label} className="medical-card">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-foreground">{stat.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              <div className={`flex items-center gap-1 mt-2 text-sm ${stat.trend === 'up' ? 'text-green-600' : 'text-blue-600'}`}>
                <TrendingUp className="w-4 h-4" />
                <span>{stat.change} from yesterday</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Emergency Types */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg">Emergency Types Distribution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {emergencyTypes.map((item) => (
              <div key={item.type}>
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-medium">{item.type}</span>
                  <span className="text-muted-foreground">{item.count} ({item.percentage}%)</span>
                </div>
                <Progress value={item.percentage} className="h-3" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Hourly Distribution */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg">Hourly Call Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between h-48 gap-2">
              {hourlyData.map((item) => (
                <div key={item.hour} className="flex flex-col items-center flex-1">
                  <div
                    className="w-full bg-primary rounded-t transition-all"
                    style={{ height: `${(item.calls / 15) * 100}%` }}
                  />
                  <span className="text-xs text-muted-foreground mt-2">{item.hour}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Response Time Breakdown */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="text-lg">Response Time Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <Clock className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-600">4.2 min</div>
              <div className="text-sm text-muted-foreground">Dispatch Time</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Ambulance className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-600">7.2 min</div>
              <div className="text-sm text-muted-foreground">Scene Arrival</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Activity className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-600">12.5 min</div>
              <div className="text-sm text-muted-foreground">Hospital Arrival</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <Users className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-600">94%</div>
              <div className="text-sm text-muted-foreground">Target Met</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Analytics;
