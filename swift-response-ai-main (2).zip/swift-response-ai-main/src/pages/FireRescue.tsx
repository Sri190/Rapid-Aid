import React from 'react';
import { Flame, MapPin, Users, Clock, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const mockFireUnits = [
  { id: 'ENG-07', name: 'Engine 7', status: 'on-scene', crew: 4, location: '789 Industrial Park' },
  { id: 'ENG-12', name: 'Engine 12', status: 'available', crew: 4, location: 'Station 3' },
  { id: 'LAD-02', name: 'Ladder 2', status: 'en-route', crew: 6, location: 'En route to call' },
  { id: 'RES-01', name: 'Rescue 1', status: 'available', crew: 3, location: 'Station 1' },
];

const FireRescue: React.FC = () => {
  const statusColors = {
    available: 'bg-green-100 text-green-700',
    'on-scene': 'bg-orange-100 text-orange-700',
    'en-route': 'bg-purple-100 text-purple-700',
    dispatched: 'bg-blue-100 text-blue-700',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Flame className="w-7 h-7 text-red-500" />
            Fire & Rescue Tracking
          </h1>
          <p className="text-muted-foreground mt-1">Monitor fire and rescue unit deployment</p>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="w-3 h-3 rounded-full bg-green-500" />
          <span>Available: {mockFireUnits.filter(u => u.status === 'available').length}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockFireUnits.map((unit) => (
          <Card key={unit.id} className="medical-card hover:shadow-lg transition-all cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    'w-12 h-12 rounded-xl flex items-center justify-center',
                    unit.status === 'available' ? 'bg-green-100' : 'bg-red-100'
                  )}>
                    <Flame className={cn(
                      'w-6 h-6',
                      unit.status === 'available' ? 'text-green-600' : 'text-red-600'
                    )} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{unit.name}</h3>
                    <p className="text-sm text-muted-foreground font-mono">{unit.id}</p>
                  </div>
                </div>
                <span className={cn(
                  'px-3 py-1 rounded-full text-xs font-medium',
                  statusColors[unit.status as keyof typeof statusColors]
                )}>
                  {unit.status}
                </span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>{unit.crew} crew members</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span className="truncate">{unit.location}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="text-lg">Active Fire Incidents</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-orange-50 rounded-lg border border-orange-100">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold">Building Fire - Industrial Park</h4>
                <p className="text-sm text-muted-foreground mt-1">789 Industrial Park Rd</p>
                <div className="flex items-center gap-4 mt-2 text-sm">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    20 min ago
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    12 affected
                  </span>
                </div>
              </div>
              <Button>
                View Details
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FireRescue;
