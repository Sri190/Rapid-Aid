import React from 'react';
import {
  Bell,
  AlertTriangle,
  Info,
  CheckCircle,
  Clock,
  Ambulance,
  Building2,
  X,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface Notification {
  id: string;
  type: 'alert' | 'info' | 'success' | 'warning';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'alert',
    title: 'High Priority Emergency',
    message: 'New cardiac arrest case reported at 123 Main Street. Immediate response required.',
    timestamp: new Date(Date.now() - 2 * 60000),
    read: false,
  },
  {
    id: '2',
    type: 'warning',
    title: 'Ambulance Delay Alert',
    message: 'Rescue 1 experiencing traffic delay. Backup ambulance Rescue 4 recommended.',
    timestamp: new Date(Date.now() - 5 * 60000),
    read: false,
  },
  {
    id: '3',
    type: 'info',
    title: 'Hospital Capacity Update',
    message: 'University Hospital now diverting patients. ER at 97% capacity.',
    timestamp: new Date(Date.now() - 15 * 60000),
    read: false,
  },
  {
    id: '4',
    type: 'success',
    title: 'Emergency Resolved',
    message: 'EM-005 (Slip and Fall at Shopping Mall) has been successfully resolved.',
    timestamp: new Date(Date.now() - 30 * 60000),
    read: true,
  },
  {
    id: '5',
    type: 'info',
    title: 'Shift Change Reminder',
    message: 'Team B shift starts in 30 minutes. Please complete handover documentation.',
    timestamp: new Date(Date.now() - 45 * 60000),
    read: true,
  },
];

const Notifications: React.FC = () => {
  const [notifications, setNotifications] = React.useState(mockNotifications);

  const typeConfig = {
    alert: { icon: AlertTriangle, color: 'text-red-600 bg-red-100 border-red-200' },
    warning: { icon: AlertTriangle, color: 'text-yellow-600 bg-yellow-100 border-yellow-200' },
    info: { icon: Info, color: 'text-blue-600 bg-blue-100 border-blue-200' },
    success: { icon: CheckCircle, color: 'text-green-600 bg-green-100 border-green-200' },
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Bell className="w-7 h-7 text-primary" />
            Notifications
          </h1>
          <p className="text-muted-foreground mt-1">
            {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
          </p>
        </div>
        <Button variant="outline" onClick={markAllAsRead}>
          Mark All as Read
        </Button>
      </div>

      <div className="space-y-4">
        {notifications.map((notification) => {
          const config = typeConfig[notification.type];
          const Icon = config.icon;

          return (
            <Card
              key={notification.id}
              className={cn(
                'medical-card transition-all duration-200',
                !notification.read && 'ring-2 ring-blue-200 ring-offset-2'
              )}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center border', config.color)}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{notification.title}</h3>
                      {!notification.read && (
                        <span className="w-2 h-2 rounded-full bg-blue-500" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      <span>{Math.floor((Date.now() - notification.timestamp.getTime()) / 60000)} minutes ago</span>
                    </div>
                  </div>
                  {!notification.read && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => markAsRead(notification.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default Notifications;
