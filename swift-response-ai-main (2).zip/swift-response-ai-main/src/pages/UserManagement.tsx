import React from 'react';
import { Users, Plus, Search, MoreVertical } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const mockUsers = [
  { id: '1', name: 'Sarah Johnson', email: 'sarah@emergency.gov', role: 'Operator', status: 'active' },
  { id: '2', name: 'Michael Chen', email: 'michael@emergency.gov', role: 'Coordinator', status: 'active' },
  { id: '3', name: 'Dr. Emily Williams', email: 'emily@hospital.gov', role: 'Hospital Admin', status: 'active' },
  { id: '4', name: 'Tom Wilson', email: 'tom@emergency.gov', role: 'Paramedic', status: 'on-duty' },
  { id: '5', name: 'Lisa Park', email: 'lisa@emergency.gov', role: 'Dispatcher', status: 'offline' },
];

const UserManagement: React.FC = () => {
  const statusColors = {
    active: 'bg-green-100 text-green-700',
    'on-duty': 'bg-blue-100 text-blue-700',
    offline: 'bg-gray-100 text-gray-700',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Users className="w-7 h-7 text-primary" />
            User Management
          </h1>
          <p className="text-muted-foreground mt-1">Manage system users and permissions</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add User
        </Button>
      </div>

      <Card className="medical-card">
        <CardHeader className="border-b">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Search users..." className="pl-10" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            {mockUsers.map((user) => (
              <div key={user.id} className="p-4 hover:bg-gray-50 transition-colors flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-semibold text-primary">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground">{user.role}</span>
                  <span className={cn('text-xs px-2 py-1 rounded-full', statusColors[user.status as keyof typeof statusColors])}>
                    {user.status}
                  </span>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagement;
