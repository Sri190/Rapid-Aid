import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Server,
  Ambulance,
  Building2,
  Route,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  ArrowRight,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const BackupFailover: React.FC = () => {
  const navigate = useNavigate();

  const backupResources = [
    {
      category: 'Primary Ambulance',
      primary: { name: 'Rescue 1', status: 'Active', eta: '8 min', healthy: true },
      backup: { name: 'Rescue 4', status: 'Standby', eta: '10 min', healthy: true },
    },
    {
      category: 'Fire Unit',
      primary: { name: 'Engine 7', status: 'On Scene', eta: '-', healthy: true },
      backup: { name: 'Engine 12', status: 'Available', eta: '15 min', healthy: true },
    },
    {
      category: 'Hospital',
      primary: { name: 'City General', status: 'Accepting', eta: '12 min', healthy: true },
      backup: { name: "St. Mary's", status: 'Available', eta: '18 min', healthy: true },
    },
    {
      category: 'Route',
      primary: { name: 'Highway 12 → Main St', status: 'Clear', eta: '8 min', healthy: true },
      backup: { name: 'Industrial Rd → Oak Ave', status: 'Moderate Traffic', eta: '12 min', healthy: true },
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Server className="w-7 h-7 text-primary" />
            Backup & Failover Center
          </h1>
          <p className="text-muted-foreground mt-1">Intelligent redundancy for critical resources</p>
        </div>
        <div className="flex items-center gap-2 bg-green-50 px-4 py-2 rounded-lg">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <span className="text-sm font-medium text-green-700">All Systems Operational</span>
        </div>
      </div>

      {/* Failover Logic Explanation */}
      <Card className="medical-card bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-100">
        <CardContent className="p-6">
          <h3 className="font-semibold text-lg mb-3">Intelligent Failover Logic</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-lg">
              <div className="text-sm font-medium text-blue-700 mb-2">1. Delay Detection</div>
              <p className="text-xs text-muted-foreground">
                System monitors real-time ETA and detects delays exceeding 3 minutes
              </p>
            </div>
            <div className="p-4 bg-white rounded-lg">
              <div className="text-sm font-medium text-blue-700 mb-2">2. Backup Evaluation</div>
              <p className="text-xs text-muted-foreground">
                AI compares backup resource ETA and calculates optimal switch timing
              </p>
            </div>
            <div className="p-4 bg-white rounded-lg">
              <div className="text-sm font-medium text-blue-700 mb-2">3. Human Approval</div>
              <p className="text-xs text-muted-foreground">
                Operator confirms switch with one-click approval, logged for audit
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Resource Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {backupResources.map((resource, idx) => (
          <Card key={idx} className="medical-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                {resource.category === 'Primary Ambulance' && <Ambulance className="w-5 h-5 text-blue-500" />}
                {resource.category === 'Fire Unit' && <AlertTriangle className="w-5 h-5 text-red-500" />}
                {resource.category === 'Hospital' && <Building2 className="w-5 h-5 text-green-500" />}
                {resource.category === 'Route' && <Route className="w-5 h-5 text-purple-500" />}
                {resource.category}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Primary */}
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-blue-700 uppercase">Primary</span>
                  <div className="flex items-center gap-1">
                    <div className={cn(
                      'w-2 h-2 rounded-full',
                      resource.primary.healthy ? 'bg-green-500' : 'bg-red-500'
                    )} />
                    <span className="text-xs text-blue-600">{resource.primary.status}</span>
                  </div>
                </div>
                <p className="font-medium">{resource.primary.name}</p>
                <p className="text-sm text-muted-foreground">ETA: {resource.primary.eta}</p>
              </div>

              {/* Arrow */}
              <div className="flex justify-center">
                <RefreshCw className="w-5 h-5 text-muted-foreground" />
              </div>

              {/* Backup */}
              <div className="p-4 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-gray-600 uppercase">Backup</span>
                  <div className="flex items-center gap-1">
                    <div className={cn(
                      'w-2 h-2 rounded-full',
                      resource.backup.healthy ? 'bg-green-500' : 'bg-red-500'
                    )} />
                    <span className="text-xs text-gray-600">{resource.backup.status}</span>
                  </div>
                </div>
                <p className="font-medium">{resource.backup.name}</p>
                <p className="text-sm text-muted-foreground">ETA: {resource.backup.eta}</p>
              </div>

              <Button variant="outline" size="sm" className="w-full">
                Switch to Backup
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* System Health */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="text-lg">System Health</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-green-50 rounded-lg text-center">
              <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <p className="font-medium">GPS Tracking</p>
              <p className="text-xs text-green-600">Operational</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg text-center">
              <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <p className="font-medium">Communication</p>
              <p className="text-xs text-green-600">Connected</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg text-center">
              <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <p className="font-medium">AI Engine</p>
              <p className="text-xs text-green-600">Active</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg text-center">
              <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <p className="font-medium">Database</p>
              <p className="text-xs text-green-600">Synced</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BackupFailover;
