import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

export type UserRole = 'operator' | 'ambulance' | 'hospital';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<boolean>;
  logout: () => void;
  getRoleLabel: (role: UserRole) => string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const roleLabels: Record<UserRole, string> = {
  operator: 'Emergency Control Room Operator',
  ambulance: 'Ambulance / Rescue Team Coordinator',
  hospital: 'Hospital Emergency Administrator',
};

const mockUsers: Record<UserRole, User> = {
  operator: {
    id: '1',
    email: 'operator@emergency.gov',
    name: 'Sarah Johnson',
    role: 'operator',
  },
  ambulance: {
    id: '2',
    email: 'rescue@emergency.gov',
    name: 'Michael Chen',
    role: 'ambulance',
  },
  hospital: {
    id: '3',
    email: 'admin@hospital.gov',
    name: 'Dr. Emily Williams',
    role: 'hospital',
  },
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('emergency_user');
    return stored ? JSON.parse(stored) : null;
  });

  const login = useCallback(async (email: string, password: string, role: UserRole): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Mock authentication - accept any email/password with valid role
    if (email && password && role) {
      const mockUser = { ...mockUsers[role], email };
      setUser(mockUser);
      localStorage.setItem('emergency_user', JSON.stringify(mockUser));
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('emergency_user');
  }, []);

  const getRoleLabel = useCallback((role: UserRole) => roleLabels[role], []);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout, getRoleLabel }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
