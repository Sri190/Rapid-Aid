import React, { createContext, useContext, useState, ReactNode } from 'react';

export type EmergencyMode = 'normal' | 'peak' | 'disaster';
export type Priority = 'high' | 'medium' | 'low';
export type EmergencyStatus = 'incoming' | 'dispatched' | 'en-route' | 'on-scene' | 'resolved';

export interface Emergency {
  id: string;
  type: string;
  category: 'medical' | 'fire' | 'accident' | 'natural-disaster' | 'crime';
  location: {
    address: string;
    lat: number;
    lng: number;
  };
  callerInfo: {
    name: string;
    phone: string;
    emotionState: 'calm' | 'anxious' | 'panic';
  };
  timeReceived: Date;
  severity: number;
  peopleAffected: number;
  priority: Priority;
  priorityScore: number;
  status: EmergencyStatus;
  assignedAmbulance?: string;
  assignedHospital?: string;
  eta?: number;
  notes: string[];
  transcript?: string;
}

export interface Ambulance {
  id: string;
  callSign: string;
  status: 'available' | 'dispatched' | 'en-route' | 'on-scene' | 'returning';
  location: { lat: number; lng: number };
  crew: string[];
  currentEmergency?: string;
  eta?: number;
}

export interface Hospital {
  id: string;
  name: string;
  location: { lat: number; lng: number };
  totalBeds: number;
  availableBeds: number;
  icuBeds: number;
  icuAvailable: number;
  erCapacity: number;
  erCurrent: number;
  status: 'accepting' | 'limited' | 'diverting';
}

interface EmergencyContextType {
  mode: EmergencyMode;
  setMode: (mode: EmergencyMode) => void;
  emergencies: Emergency[];
  ambulances: Ambulance[];
  hospitals: Hospital[];
  selectedEmergency: Emergency | null;
  setSelectedEmergency: (emergency: Emergency | null) => void;
  dispatchAmbulance: (emergencyId: string, ambulanceId: string) => void;
  updateEmergencyStatus: (emergencyId: string, status: EmergencyStatus) => void;
}

const EmergencyContext = createContext<EmergencyContextType | undefined>(undefined);

// Mock data
const mockEmergencies: Emergency[] = [
  {
    id: 'EM-001',
    type: 'Cardiac Arrest',
    category: 'medical',
    location: { address: '123 Main Street, Downtown', lat: 40.7128, lng: -74.006 },
    callerInfo: { name: 'John Smith', phone: '555-0101', emotionState: 'panic' },
    timeReceived: new Date(Date.now() - 5 * 60000),
    severity: 9,
    peopleAffected: 1,
    priority: 'high',
    priorityScore: 94,
    status: 'dispatched',
    assignedAmbulance: 'AMB-01',
    assignedHospital: 'City General Hospital',
    eta: 8,
    notes: ['Patient unresponsive', 'CPR in progress by bystander'],
    transcript: 'Help! My father just collapsed, he\'s not breathing!',
  },
  {
    id: 'EM-002',
    type: 'Vehicle Collision',
    category: 'accident',
    location: { address: '45 Highway Exit 12', lat: 40.7282, lng: -73.994 },
    callerInfo: { name: 'Maria Garcia', phone: '555-0202', emotionState: 'anxious' },
    timeReceived: new Date(Date.now() - 12 * 60000),
    severity: 7,
    peopleAffected: 3,
    priority: 'high',
    priorityScore: 87,
    status: 'en-route',
    assignedAmbulance: 'AMB-03',
    eta: 5,
    notes: ['Multiple vehicles involved', 'Possible entrapment'],
  },
  {
    id: 'EM-003',
    type: 'Building Fire',
    category: 'fire',
    location: { address: '789 Industrial Park', lat: 40.7489, lng: -73.968 },
    callerInfo: { name: 'Security Guard', phone: '555-0303', emotionState: 'calm' },
    timeReceived: new Date(Date.now() - 20 * 60000),
    severity: 8,
    peopleAffected: 12,
    priority: 'high',
    priorityScore: 91,
    status: 'on-scene',
    notes: ['Fire department on scene', 'Evacuation in progress'],
  },
  {
    id: 'EM-004',
    type: 'Allergic Reaction',
    category: 'medical',
    location: { address: '567 Restaurant Row', lat: 40.7614, lng: -73.977 },
    callerInfo: { name: 'Restaurant Staff', phone: '555-0404', emotionState: 'anxious' },
    timeReceived: new Date(Date.now() - 3 * 60000),
    severity: 6,
    peopleAffected: 1,
    priority: 'medium',
    priorityScore: 68,
    status: 'incoming',
    notes: ['EpiPen administered', 'Patient conscious'],
  },
  {
    id: 'EM-005',
    type: 'Slip and Fall',
    category: 'medical',
    location: { address: '234 Shopping Mall', lat: 40.7549, lng: -73.984 },
    callerInfo: { name: 'Mall Security', phone: '555-0505', emotionState: 'calm' },
    timeReceived: new Date(Date.now() - 45 * 60000),
    severity: 3,
    peopleAffected: 1,
    priority: 'low',
    priorityScore: 32,
    status: 'resolved',
    notes: ['Minor injury', 'First aid provided'],
  },
];

const mockAmbulances: Ambulance[] = [
  { id: 'AMB-01', callSign: 'Rescue 1', status: 'dispatched', location: { lat: 40.7138, lng: -74.003 }, crew: ['Tom Wilson', 'Lisa Park'], currentEmergency: 'EM-001', eta: 8 },
  { id: 'AMB-02', callSign: 'Rescue 2', status: 'available', location: { lat: 40.7328, lng: -73.987 }, crew: ['James Brown', 'Emma Davis'] },
  { id: 'AMB-03', callSign: 'Rescue 3', status: 'en-route', location: { lat: 40.7250, lng: -73.990 }, crew: ['Mike Johnson', 'Sarah Lee'], currentEmergency: 'EM-002', eta: 5 },
  { id: 'AMB-04', callSign: 'Rescue 4', status: 'available', location: { lat: 40.7450, lng: -73.975 }, crew: ['David Kim', 'Rachel Green'] },
  { id: 'AMB-05', callSign: 'Rescue 5', status: 'returning', location: { lat: 40.7600, lng: -73.970 }, crew: ['Chris Martin', 'Amy Chen'] },
];

const mockHospitals: Hospital[] = [
  { id: 'HOSP-01', name: 'City General Hospital', location: { lat: 40.7180, lng: -74.000 }, totalBeds: 450, availableBeds: 38, icuBeds: 40, icuAvailable: 5, erCapacity: 60, erCurrent: 42, status: 'accepting' },
  { id: 'HOSP-02', name: 'Metro Medical Center', location: { lat: 40.7400, lng: -73.985 }, totalBeds: 320, availableBeds: 12, icuBeds: 25, icuAvailable: 2, erCapacity: 45, erCurrent: 41, status: 'limited' },
  { id: 'HOSP-03', name: 'St. Mary\'s Hospital', location: { lat: 40.7550, lng: -73.960 }, totalBeds: 280, availableBeds: 45, icuBeds: 20, icuAvailable: 8, erCapacity: 35, erCurrent: 18, status: 'accepting' },
  { id: 'HOSP-04', name: 'University Hospital', location: { lat: 40.7650, lng: -73.955 }, totalBeds: 520, availableBeds: 5, icuBeds: 50, icuAvailable: 0, erCapacity: 70, erCurrent: 68, status: 'diverting' },
];

export const EmergencyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [mode, setMode] = useState<EmergencyMode>('normal');
  const [emergencies, setEmergencies] = useState<Emergency[]>(mockEmergencies);
  const [ambulances, setAmbulances] = useState<Ambulance[]>(mockAmbulances);
  const [hospitals] = useState<Hospital[]>(mockHospitals);
  const [selectedEmergency, setSelectedEmergency] = useState<Emergency | null>(null);

  const dispatchAmbulance = (emergencyId: string, ambulanceId: string) => {
    setAmbulances(prev => prev.map(amb => 
      amb.id === ambulanceId 
        ? { ...amb, status: 'dispatched' as const, currentEmergency: emergencyId, eta: Math.floor(Math.random() * 10) + 5 }
        : amb
    ));
    setEmergencies(prev => prev.map(em =>
      em.id === emergencyId
        ? { ...em, status: 'dispatched', assignedAmbulance: ambulanceId }
        : em
    ));
  };

  const updateEmergencyStatus = (emergencyId: string, status: EmergencyStatus) => {
    setEmergencies(prev => prev.map(em =>
      em.id === emergencyId ? { ...em, status } : em
    ));
  };

  return (
    <EmergencyContext.Provider value={{
      mode,
      setMode,
      emergencies,
      ambulances,
      hospitals,
      selectedEmergency,
      setSelectedEmergency,
      dispatchAmbulance,
      updateEmergencyStatus,
    }}>
      {children}
    </EmergencyContext.Provider>
  );
};

export const useEmergency = () => {
  const context = useContext(EmergencyContext);
  if (context === undefined) {
    throw new Error('useEmergency must be used within an EmergencyProvider');
  }
  return context;
};
