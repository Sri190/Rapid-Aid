import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  Home,
  Map,
  Phone,
  AlertTriangle,
  Brain,
  FileText,
  Truck,
  Building2,
  Route,
  TrafficCone,
  MessageSquare,
  Bell,
  History,
  FileSearch,
  BarChart3,
  Shield,
  Users,
  Settings,
  User,
  HelpCircle,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Ambulance,
  Flame,
  Server,
  Activity,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

interface NavItem {
  icon: React.ElementType;
  label: string;
  path: string;
  roles?: ('operator' | 'ambulance' | 'hospital')[];
  badge?: number;
}

const navItems: NavItem[] = [
  { icon: Home, label: 'Dashboard', path: '/dashboard' },
  { icon: Map, label: 'Live Emergency Map', path: '/map' },
  { icon: Phone, label: 'Incoming Requests', path: '/incoming', roles: ['operator'], badge: 4 },
  { icon: AlertTriangle, label: 'Active Emergencies', path: '/active', badge: 3 },
  { icon: Brain, label: 'AI Priority Queue', path: '/priority-queue', roles: ['operator'] },
  { icon: FileText, label: 'Emergency Details', path: '/emergency-details' },
  { icon: Activity, label: 'Resource Status', path: '/resources' },
  { icon: Ambulance, label: 'Ambulance Tracking', path: '/ambulance-tracking' },
  { icon: Flame, label: 'Fire & Rescue Tracking', path: '/fire-rescue' },
  { icon: Building2, label: 'Hospital Capacity', path: '/hospital-capacity' },
  { icon: Server, label: 'Backup & Failover', path: '/backup-failover' },
  { icon: Route, label: 'Route Planning', path: '/route-planning' },
  { icon: TrafficCone, label: 'Traffic Intelligence', path: '/traffic' },
  { icon: MessageSquare, label: 'Patient Reassurance', path: '/reassurance', roles: ['operator', 'ambulance'] },
  { icon: Bell, label: 'Notifications', path: '/notifications', badge: 5 },
  { icon: History, label: 'Incident History', path: '/history' },
  { icon: FileSearch, label: 'System Logs', path: '/logs' },
  { icon: BarChart3, label: 'Analytics & Insights', path: '/analytics' },
  { icon: Shield, label: 'Emergency Modes', path: '/emergency-modes' },
  { icon: Users, label: 'User Management', path: '/user-management', roles: ['operator'] },
  { icon: Settings, label: 'Settings', path: '/settings' },
  { icon: User, label: 'Profile', path: '/profile' },
  { icon: HelpCircle, label: 'Help & Support', path: '/help' },
];

const Sidebar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const filteredNavItems = navItems.filter(
    item => !item.roles || (user && item.roles.includes(user.role))
  );

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside
      className={cn(
        'h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300',
        isCollapsed ? 'w-16' : 'w-64'
      )}
    >
      {/* Logo */}
      <div className="h-16 border-b border-sidebar-border flex items-center justify-between px-4">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg text-sidebar-foreground">ERS</span>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1.5 rounded-lg hover:bg-sidebar-accent transition-colors"
        >
          {isCollapsed ? (
            <ChevronRight className="w-5 h-5 text-sidebar-foreground" />
          ) : (
            <ChevronLeft className="w-5 h-5 text-sidebar-foreground" />
          )}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto custom-scrollbar py-4">
        <ul className="space-y-1 px-2">
          {filteredNavItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group',
                    isActive
                      ? 'bg-sidebar-accent text-sidebar-primary font-medium'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                  )
                }
              >
                <item.icon className={cn('w-5 h-5 flex-shrink-0', isCollapsed && 'mx-auto')} />
                {!isCollapsed && (
                  <>
                    <span className="flex-1 truncate">{item.label}</span>
                    {item.badge && (
                      <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      {/* Logout */}
      <div className="border-t border-sidebar-border p-2">
        <button
          onClick={handleLogout}
          className={cn(
            'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-red-600 hover:bg-red-50 transition-colors',
            isCollapsed && 'justify-center'
          )}
        >
          <LogOut className="w-5 h-5" />
          {!isCollapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
