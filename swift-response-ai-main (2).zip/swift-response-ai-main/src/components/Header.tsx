import React, { useState, useEffect } from 'react';
import { Bell, User, ChevronDown, LogOut, Settings, HelpCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useEmergency, EmergencyMode } from '@/contexts/EmergencyContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useNavigate } from 'react-router-dom';

const Header: React.FC = () => {
  const { user, logout, getRoleLabel } = useAuth();
  const { mode, setMode } = useEmergency();
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const modeConfig: Record<EmergencyMode, { label: string; className: string }> = {
    normal: { label: 'Normal', className: 'mode-normal' },
    peak: { label: 'Peak', className: 'mode-peak' },
    disaster: { label: 'Disaster', className: 'mode-disaster' },
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="h-16 border-b border-border bg-white px-6 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-6">
        <div className="text-sm text-muted-foreground">
          <div className="font-semibold text-foreground">
            {currentTime.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
          <div className="font-mono text-lg font-bold text-primary">
            {currentTime.toLocaleTimeString('en-US', { hour12: false })}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {/* Emergency Mode Toggle */}
        <div className="flex items-center gap-2 bg-secondary/50 rounded-lg p-1">
          <span className="text-xs font-medium text-muted-foreground px-2">Mode:</span>
          {(['normal', 'peak', 'disaster'] as EmergencyMode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`mode-indicator transition-all ${
                mode === m ? modeConfig[m].className : 'bg-transparent text-muted-foreground hover:bg-gray-100'
              }`}
            >
              {modeConfig[m].label}
            </button>
          ))}
        </div>

        {/* Notifications */}
        <Button
          variant="ghost"
          size="icon"
          className="relative"
          onClick={() => navigate('/notifications')}
        >
          <Bell className="h-5 w-5" />
          <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
            3
          </span>
        </Button>

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2 h-auto py-2">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-4 w-4 text-primary" />
              </div>
              <div className="text-left hidden sm:block">
                <div className="text-sm font-medium">{user?.name}</div>
                <div className="text-xs text-muted-foreground">{user && getRoleLabel(user.role)}</div>
              </div>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 bg-white">
            <DropdownMenuItem onClick={() => navigate('/profile')}>
              <User className="mr-2 h-4 w-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/settings')}>
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/help')}>
              <HelpCircle className="mr-2 h-4 w-4" />
              Help & Support
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-red-600">
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default Header;
