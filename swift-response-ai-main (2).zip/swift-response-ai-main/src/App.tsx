import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { EmergencyProvider } from "./contexts/EmergencyContext";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import LiveMap from "./pages/LiveMap";
import IncomingRequests from "./pages/IncomingRequests";
import ActiveEmergencies from "./pages/ActiveEmergencies";
import PriorityQueue from "./pages/PriorityQueue";
import EmergencyDetails from "./pages/EmergencyDetails";
import AmbulanceTracking from "./pages/AmbulanceTracking";
import HospitalCapacity from "./pages/HospitalCapacity";
import BackupFailover from "./pages/BackupFailover";
import PatientReassurance from "./pages/PatientReassurance";
import Resources from "./pages/Resources";
import Notifications from "./pages/Notifications";
import Analytics from "./pages/Analytics";
import IncidentHistory from "./pages/IncidentHistory";
import SystemLogs from "./pages/SystemLogs";
import EmergencyModes from "./pages/EmergencyModes";
import UserManagement from "./pages/UserManagement";
import Settings from "./pages/Settings";
import Profile from "./pages/Profile";
import Help from "./pages/Help";
import RoutePlanning from "./pages/RoutePlanning";
import Traffic from "./pages/Traffic";
import FireRescue from "./pages/FireRescue";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <EmergencyProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route element={<Layout />}>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/map" element={<LiveMap />} />
                <Route path="/incoming" element={<IncomingRequests />} />
                <Route path="/active" element={<ActiveEmergencies />} />
                <Route path="/priority-queue" element={<PriorityQueue />} />
                <Route path="/emergency-details" element={<EmergencyDetails />} />
                <Route path="/emergency/:id" element={<EmergencyDetails />} />
                <Route path="/resources" element={<Resources />} />
                <Route path="/ambulance-tracking" element={<AmbulanceTracking />} />
                <Route path="/fire-rescue" element={<FireRescue />} />
                <Route path="/hospital-capacity" element={<HospitalCapacity />} />
                <Route path="/backup-failover" element={<BackupFailover />} />
                <Route path="/route-planning" element={<RoutePlanning />} />
                <Route path="/traffic" element={<Traffic />} />
                <Route path="/reassurance" element={<PatientReassurance />} />
                <Route path="/notifications" element={<Notifications />} />
                <Route path="/history" element={<IncidentHistory />} />
                <Route path="/logs" element={<SystemLogs />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/emergency-modes" element={<EmergencyModes />} />
                <Route path="/user-management" element={<UserManagement />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/help" element={<Help />} />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </EmergencyProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
